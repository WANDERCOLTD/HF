# @tallyseal/admin-editor

> Framework-agnostic React components for the Tallyseal IntentSpec authoring UI. FieldsTable, FieldForm, ReadinessSection, DeployButton + helpers — host (Next.js / Remix / etc.) supplies routing, auth, and the `SpecStore` implementation; this package owns the editor surface.

Extracted from `apps/admin-viewer/` in TKT-ADMIN-EDITOR-LIB-EXTRACT (2026-06-06) so HF V6 wizard Phase 2 (#1140) can vendor the editor inside HF's own Next.js app without running `apps/admin-viewer/` as a sibling Next.js service.

## Install

```bash
npm install @tallyseal/admin-editor
# or, for npm-managed customers using the vendored-tarball path:
npm install file:./vendor/tallyseal/tallyseal-admin-editor-0.1.0.tgz
```

Peer dependencies you must already have: `react@^18 || ^19` + `react-dom@^18 || ^19`.

## Primary mount path — compose individual components

This is the path HF's V6 wizard uses: mount the editor's components directly inside your own layout (LHS chat panel + RHS spec panel, sidebar layout, etc.). Each component is a focused widget that takes structured props + dispatches callbacks. The host owns the surrounding layout, the spec state, and the persistence calls.

```tsx
import { useReducer } from 'react';
import { parse, emit } from '@tallyseal/spec-emitter';
import {
  FieldsTable,
  FieldForm,
  ReadinessSection,
  DeployButton,
  createInitialEditorState,
  editorReducer,
  type SpecStore,
} from '@tallyseal/admin-editor';

// 1. Implement `SpecStore` against your persistence layer.
//    (HF: a Prisma-backed implementation against the `crawcus_spec` table.)
const myStore: SpecStore = {
  async load(key, version) {
    /* return latest draft or null */
  },
  async saveDraft(spec) {
    /* upsert against (spec.key, spec.version); reject PUBLISHED rows */
  },
  async publish(specId) {
    /* DRAFT → PUBLISHED transition; synthesise a SpecDeployOutcome */
  },
  async list(filter) {
    /* return SpecSummary[] */
  },
};

export function MySpecEditor({ specName }: { specName: string }) {
  // 2. Parse your current source into the editor's working state.
  const initialSpec = parse(rawSourceFromYourStore, { filename: `${specName}.intent.ts` });
  const [state, dispatch] = useReducer(
    editorReducer,
    initialSpec,
    createInitialEditorState,
  );

  const [roundTripStatus, setRoundTripStatus] = useState<'unchecked' | 'equal' | 'mismatch'>(
    'unchecked',
  );

  return (
    <div className="grid grid-cols-[1fr_400px] gap-4">
      {/* LHS — your chat / wizard / instructions */}
      <YourChatPanel />

      {/* RHS — the editor surface, composed from individual @tallyseal/admin-editor pieces */}
      <div className="flex flex-col gap-6">
        <FieldsTable
          fields={state.spec.fields}
          canEdit={true}
          onAdd={(field) => dispatch({ kind: 'add-field', field })}
          onUpdate={(index, field) => dispatch({ kind: 'update-field', index, field })}
          onRemove={(index) => dispatch({ kind: 'remove-field', index })}
          onMoveUp={(index) => dispatch({ kind: 'move-field-up', index })}
          onMoveDown={(index) => dispatch({ kind: 'move-field-down', index })}
        />

        <ReadinessSection
          readiness={state.spec.readiness}
          fields={state.spec.fields}
          canEdit={true}
          onToggleField={(fieldName, required) => {
            // see EditorShell.tsx for the canonical toggle reducer dispatch
          }}
        />

        <DeployButton
          canDeploy={true}
          dirty={state.dirty}
          roundTripStatus={roundTripStatus}
          deployPending={false}
          onClick={async () => {
            // your save + publish flow here, calling myStore
            await myStore.saveDraft(state.spec);
            const { deployOutcome } = await myStore.publish(specName);
            /* render success / failure panel based on deployOutcome.kind */
          }}
        />
      </div>
    </div>
  );
}
```

That's the documented primary path per HF reply on TKT-ADMIN-EDITOR-LIB-EXTRACT §6(d) (2026-06-06): HF mounts components individually because their V6 wizard layout doesn't match the default `EditorShell` arrangement.

### Component-by-component import — tree-shake friendly

Every export is named — there's no default export and no barrel `export *`. Bundlers (Next.js / Vite / esbuild / webpack 5) eliminate unused components from your bundle at production build time. If you only mount `FieldsTable` + `FieldForm`, only those two ship in your `_app` chunk.

## Alternative: `EditorShell` opinionated wrapper

For hosts that want the editor's default layout (LHS controls, single-column field table, INTERNAL_FIELDS list below, ReadinessSection at the bottom), mount the single `EditorShell` component and pass it `saveSpecSource` + `deploySpec` callbacks.

```tsx
import { EditorShell } from '@tallyseal/admin-editor';
import { parse } from '@tallyseal/spec-emitter';

const initialSpec = parse(rawSource, { filename: 'EnrollmentIntake.intent.ts' });

export function StockSpecEditor() {
  return (
    <EditorShell
      specName="EnrollmentIntake"
      initialSpec={initialSpec}
      canEdit={true}
      canDeploy={true}
      currentRole="compliance-officer"
      saveSpecSource={async ({ name, source }) => ({ kind: 'ok' })}
      deploySpec={async ({ name, source, humanDescription }) => ({
        kind: 'ok',
        prUrl: 'https://github.com/your-org/your-repo/pull/123',
        prNumber: 123,
        commitSha: 'abc123',
        bridgeAccessEventId: 'evt_xyz',
      })}
    />
  );
}
```

`EditorShell` is one option alongside the individual-component path — not the primary path. Per HF reply on TKT-ADMIN-EDITOR-LIB-EXTRACT §6(d): HF does NOT use `EditorShell` because their V6 wizard layout is custom.

## The `SpecStore` contract

`SpecStore` is the data contract the host implements. The package never imports `prisma` or anything DB-specific — the host owns the persistence story.

```ts
import type { SpecStore, SpecDeployOutcome } from '@tallyseal/admin-editor';
import type { CrawcusSpec } from '@tallyseal/core';

const myStore: SpecStore = {
  async load(key: string, version?: string): Promise<CrawcusSpec | null> {
    // load latest draft (or specified version) from your DB
  },

  async saveDraft(spec: CrawcusSpec): Promise<{ id: string; version: string }> {
    // Upsert against (spec.key, spec.version).
    // MUST refuse writes against PUBLISHED rows.
    const existing = await findByKeyVersion(spec.key, spec.version);
    if (existing?.status === 'PUBLISHED') throw new Error('immutable');
    return existing ? updateDraft(existing.id, spec) : createDraft(spec);
  },

  async publish(specId: string): Promise<{ deployOutcome: SpecDeployOutcome }> {
    // Transition DRAFT → PUBLISHED. You MAY synthesise a structurally-valid
    // SpecDeployOutcome from the post-publish row — the package does NOT
    // require a real remote deploy receipt to render the post-publish UI.
    const published = await transitionDraftToPublished(specId);
    return {
      deployOutcome: {
        kind: 'ok',
        prUrl: '', // empty if in-DB publish; populate for PR-mode flow
        prNumber: 0,
        commitSha: published.commitSha ?? '',
        bridgeAccessEventId: published.auditEventId,
      },
    };
  },

  async list(filter?: { status?: 'DRAFT' | 'PUBLISHED' }) {
    // return SpecSummary[] for the list-view UI
  },
};
```

Both `saveDraft` JSDoc semantics (upsert + PUBLISHED-row refusal) and `publish` JSDoc semantics (host-synthesised `SpecDeployOutcome` accepted) are locked surface decisions per the spec memo §6(b).

## Theming — `data-tallyseal` attribute scope

The package's components consume CSS variables under the `--tallyseal-*` namespace. Hosts can scope them per editor instance with `data-tallyseal="editor"`:

```css
[data-tallyseal='editor'] {
  --tallyseal-accent: var(--your-brand-accent);
  --tallyseal-accent-border: var(--your-brand-accent-border);
  --tallyseal-primary-tint: var(--your-brand-tint);
  --tallyseal-primary-border: var(--your-brand-border);
  --tallyseal-text-dark: var(--your-brand-text-dark);
  --tallyseal-text-muted: var(--your-brand-text-muted);
  --tallyseal-verdict-fail: var(--your-brand-error);
}
```

```tsx
<div data-tallyseal="editor">
  <FieldsTable {...props} />
  <ReadinessSection {...props} />
</div>
```

Mirrors the `data-tallyseal` theming convention from `@tallyseal/react-assistant-ui`. The package ships sensible Tailwind utility defaults; the variables let you override per host.

## What's NOT in this package

- **No `next/*` imports** — the package is framework-agnostic React. Pages, server actions, and route handlers stay in your host app.
- **No `'use server'` directives** — server-side logic is the host's responsibility.
- **No `prisma` imports** — the `SpecStore` contract is the abstraction boundary; you implement it against your persistence layer.
- **No auth** — the host enforces role/scope before mounting the editor.
- **No deploy-action wiring** — `apps/admin-viewer/` ships a reference Next.js server-action that wraps `validateDeployInput` + `bridgeDeploy`; consumers replicate the pattern in their own framework idiom.

## Library helpers — for hosts that build a custom shell

The package also exposes the pure helpers `apps/admin-viewer/` uses, so you can build a fully custom editor without re-implementing field validation, readiness emit/parse, or the spec reducer:

- `validateFieldName` + `formatFieldNameError` — camelCase / reserved / duplicate enforcement
- `EDITOR_VISIBLE_FIELD_TYPES` + `RESERVED_FIELD_NAMES` — the surface-spec catalogs
- `classifyReadiness` + `hasAllOfBlockFormPattern` — readiness predicate UI classification
- `emitReadinessAllOf` + `emitReadinessPreview` — readiness predicate emit slices
- `editorReducer` + `createInitialEditorState` + the `EditorAction` union — the spec state reducer
- `buildEditableFieldFromFormValues` + `extractFormValuesFromField` — form ↔ spec helpers
- `validateDeployInput` + `mapBridgeResult` — pure deploy pipeline helpers
- `HUMAN_DESCRIPTION_MIN_LENGTH` / `HUMAN_DESCRIPTION_MAX_LENGTH` / `COMMIT_SUBJECT_CAP` — deploy modal length constants

## Reference consumer

[`apps/admin-viewer/`](../../apps/admin-viewer) in this monorepo is the reference consumer — it ships the Next.js server actions, the OIDC auth, and the role-gate that wrap this package's components. Read the `apps/admin-viewer/src/app/intents/specs/[name]/edit/page.tsx` source for the complete integration pattern.

## License

MIT — `@tallyseal/admin-editor` is part of Tallyseal's wide-OSS surface (C3 Option D LOCKED 2026-05-20). Use freely, including in commercial products. Optional paid services live under `@tallyseal/cloud-*` (not yet published).

## Status

- **v0.1.0** (2026-06-06): initial extraction from `apps/admin-viewer/`. Six surface decisions locked 2026-06-06 per HF reply on TKT-ADMIN-EDITOR-LIB-EXTRACT §6.
