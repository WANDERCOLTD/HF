# @tallyseal/prisma-adapter

Prisma-backed `EventStorePort` + default `ProjectionPort` + SQL
migrations for Tallyseal.

Per **Q6 LOCKED 2026-05-21 — Option A**: ships immutable SQL
migrations in `migrations/`, applied by a hand-rolled runner
(`applyMigrations(client)`); the customer's `schema.prisma` does NOT
need any Tallyseal model declarations — the adapter uses raw SQL
(`$queryRawUnsafe` / `$executeRawUnsafe`) against the tables our
migrations create.

## Install

```bash
pnpm add @tallyseal/prisma-adapter @tallyseal/core @prisma/client
```

## Setup — one-time

```ts
import { PrismaClient } from '@prisma/client';
import { applyMigrations } from '@tallyseal/prisma-adapter';

const prisma = new PrismaClient();
const result = await applyMigrations(prisma);
console.log(`Applied: ${result.applied.length}, skipped: ${result.skipped.length}`);
```

Or via the (future) CLI:

```bash
npx @tallyseal/generator migrate
```

Idempotent — safe to run on every deploy.

## Wire into `defineConfig`

```ts
import { defineConfig } from '@tallyseal/core';
import { PrismaEventStore, PrismaNoopProjection } from '@tallyseal/prisma-adapter';

const prisma = new PrismaClient();

export default defineConfig({
  eventStore: new PrismaEventStore(prisma),
  projection: new PrismaNoopProjection(),
  // ... other ports
});
```

## Same-transaction guarantee (ratchet #13)

`PrismaEventStore.begin(tenant, fn)` opens a `client.$transaction(...)`.
Inside the callback, `tx.__tx.raw` is the Prisma transaction client
— customer's per-intent reducers (registered via
`defineProjection({...})`) get this through `ReducerCtx.tx`. The
event append + the projection write commit atomically.

## Atomic Event+projection writes (`writeEventWithProjection`)

For the common case where intake-flow code emits an Event AND wants
to write a typed-table projection (Warrant / Disclosure / DisclosureSignal /
Consent / HumanOversight / OversightFinding) in lockstep, use the
`writeEventWithProjection` helper. It opens ONE Prisma `$transaction`
and writes both atomically — either both commit or neither does.

```ts
import {
  writeEventWithProjection,
  type ProjectionWrite,
} from '@tallyseal/prisma-adapter';
import { computeContentHash } from '@tallyseal/crawcus-spec';

// 1. Build the Event (caller computes contentHash + prevHash).
const event = makeDisclosureDeliveredEvent(/* ... */);

// 2. Build the projection record.
const disclosure: Disclosure = {
  id: 'dsc_001' as DisclosureId,
  tenantId,
  subject,
  requirementId: 'gdpr-art-13-notice' as DisclosureRequirementId,
  content: { text: 'We process your data ...', format: 'text', locale: 'en' },
  contentHash: 'h_v1' as ContentHash,
  deliveredAt: '2026-06-05T00:00:00.000Z' as Timestamp,
  deliveryMethod: 'in-app',
  acknowledgedAt: null,
  retractedAt: null,
};

// 3. Atomically write both inside one transaction.
const result = await writeEventWithProjection({
  event,
  projection: { kind: 'disclosure', record: disclosure },
  client: prisma,
});
// → result.event === event; result.projection === disclosure
```

### Discriminator values

| `kind` | Writes to | Record shape |
|---|---|---|
| `'warrant'` | `tallyseal_warrant` | `Warrant` |
| `'disclosure'` | `tallyseal_disclosure` | `Disclosure` |
| `'disclosure-signal'` | `tallyseal_disclosure_signal` | `RecordSignalInput` |
| `'consent'` | `tallyseal_consent` | `Consent` |
| `'oversight-requirement'` | `tallyseal_oversight` (+ findings) | `HumanOversight` |
| `'oversight-finding'` | `tallyseal_oversight_finding` | `RecordOversightFindingInput` |

### Q-CR9 SIGNAL-not-gate (LOAD-BEARING)

`'disclosure'` and `'disclosure-signal'` are SEPARATE discriminator
values — they write to SEPARATE tables. A `'disclosure-signal'` write
CANNOT mutate `tallyseal_disclosure.acknowledged_at`. This preserves
the Q-CR9 structural separation at the helper layer (defence-in-depth
on top of the schema-layer separation in
`migrations/0003_add_disclosure.sql`). Pinned by a regression test in
`test/write-event-with-projection.test.ts`.

### Atomicity — both writes or neither

If the projection insert throws (e.g., unique-constraint violation),
the entire transaction rolls back — the Event is NOT committed to the
chain. Conversely, if the Event append throws (e.g., monotonic-version
collision), the projection is NOT committed. No partial state is
structurally reachable.

### Lineage is intentionally absent

Lineage auto-records via `writeEvent` per Q-CR7 — it doesn't fit the
"caller specifies projection" pattern. Use the standard `writeEvent`
path for Lineage.

## Row mappers

Pure row → runtime mappers for read paths (`apps/admin-bridge` callbacks, customer queries):

| Helper | Maps | From |
|---|---|---|
| `rowToEvent(row)` | `Event` | `TallysealEventRow` (canonical `tallyseal_event` row) |
| `rowToIntent(row)` | `Intent` | `TallysealIntentRow` (canonical `tallyseal_intent` row) |

Use the brand-cast typed-id shape — the helpers return values structurally assignable to `IntentId` / `TenantId` / `IntentKey` without further casting.

## Tables created

| Table | Purpose |
|---|---|
| `tallyseal_event` | Append-only event log; UUIDv7 IDs; UNIQUE(intent_id, version); GIN index on data_subject_ids for DSAR |
| `tallyseal_intent` | Intent runtime state + accumulated snapshot |
| `tallyseal_suggestion` | Suggestion lifecycle records (Art. 14 surface) |
| `_tallyseal_migrations` | Internal: applied-migration ledger with SHA-256 checksums |

All tables are prefixed `tallyseal_` to avoid collisions; all carry
`tenant_id` + index. Partitioning is an adapter optimisation
deferred to S1 load testing.

## Migrations are immutable (ratchet #4)

Migrations in `migrations/` are forward-only. The runner records a
SHA-256 checksum of each file when applied. If a previously-applied
file is later edited, the runner REFUSES on next run with a clear
error — never silently re-applies.

To change schema after release: add a NEW forward migration with a
higher numeric prefix. Never edit historical files.

## Status

v0.2.0 — primitives 10-14 stores (Warrant / Disclosure +
DisclosureSignal / Consent / Lineage / HumanOversight) shipped per
TKT-PRISMA-ADAPTER-PRIMITIVES-10-14; `rowToIntent` mapper per
TKT-PRISMA-ROW-TO-INTENT; `writeEventWithProjection` atomic helper per
TKT-WRITE-EVENT-WITH-PROJECTION. Integration tested against pg-mem +
mutation-tested via Stryker per ratchet #2.

## License

MIT.
