-- Tallyseal prisma-adapter migration 0001 — initial schema.
-- IMMUTABLE per ratchet #4. Never edit; only add forward migrations.
--
-- Tables created (all prefixed `tallyseal_` to avoid namespace
-- collisions with customer tables):
--   tallyseal_intent       — Intent runtime state + accumulated snapshot
--   tallyseal_event        — append-only event log + hash chain
--   tallyseal_suggestion   — Suggestion lifecycle records (Art. 14 surface)
--   _tallyseal_migrations  — internal: applied-migration ledger
--
-- All tables are tenant-scoped (`tenant_id` column + index); NOT
-- partitioned by tenant in v0.0.1 — partitioning is an adapter
-- optimisation deferred until S1 load test (NFR Q22 territory).

CREATE TABLE IF NOT EXISTS _tallyseal_migrations (
  filename   TEXT PRIMARY KEY,
  applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  checksum   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tallyseal_intent (
  id            TEXT PRIMARY KEY,
  tenant_id     TEXT NOT NULL,
  key           TEXT NOT NULL,
  spec_version  INTEGER NOT NULL,
  state         TEXT NOT NULL CHECK (state IN ('open', 'committed', 'abandoned')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  snapshot      JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS tallyseal_intent_tenant_idx ON tallyseal_intent (tenant_id);
CREATE INDEX IF NOT EXISTS tallyseal_intent_key_idx ON tallyseal_intent (key);

CREATE TABLE IF NOT EXISTS tallyseal_event (
  id                      UUID PRIMARY KEY,
  tenant_id               TEXT NOT NULL,
  intent_id               TEXT NOT NULL,
  kind                    TEXT NOT NULL,
  version                 INTEGER NOT NULL,
  timestamp               TIMESTAMPTZ NOT NULL,
  actor                   JSONB NOT NULL,
  lawful_basis            TEXT NOT NULL,
  purpose                 TEXT NOT NULL,
  data_subject_ids        TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  consent_event_id        TEXT,
  special_category_basis  TEXT,
  prev_hash               TEXT,
  content_hash            TEXT NOT NULL,
  payload                 JSONB NOT NULL,
  ai                      JSONB,
  correlation_id          TEXT,
  causation_id            TEXT,
  -- Unique-per-intent version: enforces monotonic versioning + idempotency
  UNIQUE (intent_id, version)
);
CREATE INDEX IF NOT EXISTS tallyseal_event_tenant_idx ON tallyseal_event (tenant_id);
CREATE INDEX IF NOT EXISTS tallyseal_event_intent_idx ON tallyseal_event (intent_id, version);
CREATE INDEX IF NOT EXISTS tallyseal_event_kind_idx ON tallyseal_event (kind);
-- GIN index for GDPR Art. 15 DSAR — subject-ID search across 10M+ events
-- per NFR S8 (subject-ID search latency).
CREATE INDEX IF NOT EXISTS tallyseal_event_subjects_idx ON tallyseal_event USING GIN (data_subject_ids);

CREATE TABLE IF NOT EXISTS tallyseal_suggestion (
  id                 TEXT PRIMARY KEY,
  intent_id          TEXT NOT NULL REFERENCES tallyseal_intent(id) ON DELETE CASCADE,
  tenant_id          TEXT NOT NULL,
  field_key          TEXT NOT NULL,
  proposed_value     JSONB NOT NULL,
  state              TEXT NOT NULL CHECK (state IN ('proposed', 'accepted', 'edited', 'rejected', 'superseded')),
  confidence         REAL NOT NULL CHECK (confidence >= 0 AND confidence <= 1),
  proposed_by_event  UUID NOT NULL,
  superseded_by      TEXT,
  accepted_as        JSONB,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS tallyseal_suggestion_tenant_idx ON tallyseal_suggestion (tenant_id);
CREATE INDEX IF NOT EXISTS tallyseal_suggestion_intent_idx ON tallyseal_suggestion (intent_id);
CREATE INDEX IF NOT EXISTS tallyseal_suggestion_state_idx ON tallyseal_suggestion (state);
