-- Tallyseal prisma-adapter migration 0006 — add HumanOversight
-- (primitive #14). IMMUTABLE per ratchet #4. Forward-only; add another
-- migration to evolve.
--
-- Two tables — outer + denormalised findings for cross-oversight query:
--   tallyseal_oversight         — the conducted review record
--   tallyseal_oversight_finding — individual findings (1:N from oversight)
--
-- Per Q-CR8 LOCKED 2026-05-22: OverseerRole closed-union enforced via
-- CHECK constraint on `overseer_role`. Day-1 values:
--   'individual' | 'committee' | 'rotation' | 'compliance-officer' |
--   'ethics-board' | 'notified-body'
-- Additions ship via additive-MINOR forward migration.

CREATE TABLE IF NOT EXISTS tallyseal_oversight (
  id                              TEXT PRIMARY KEY,
  tenant_id                       TEXT NOT NULL,
  requirement_id                  TEXT NOT NULL,
  -- OverseerRef carried verbatim per Q-CR8 (lossy round-trip caught
  -- by TCK fixture). The denormalised columns below mirror the
  -- canonical embedded JSON for indexing + query.
  overseer                        JSONB NOT NULL,
  overseer_actor_id               TEXT NOT NULL,
  overseer_role                   TEXT NOT NULL CHECK (overseer_role IN (
    'individual','committee','rotation','compliance-officer','ethics-board','notified-body'
  )),
  overseer_org_id                 TEXT NOT NULL,
  overseer_name                   TEXT NOT NULL,
  -- For 'committee' role: members beyond the chair. NULL otherwise.
  overseer_committee_members      TEXT[],
  -- For 'rotation' role: term-end timestamp. NULL otherwise.
  overseer_rotation_ends_at       TIMESTAMPTZ,
  -- OversightScope { kind, ... } discriminated union — opaque JSONB.
  scope                           JSONB NOT NULL,
  mode                            TEXT NOT NULL CHECK (mode IN ('in-loop','on-loop','retrospective')),
  conducted_at                    TIMESTAMPTZ NOT NULL,
  outcome                         TEXT NOT NULL CHECK (outcome IN ('signed-off','escalated','remediation-required')),
  -- RegulationCitation embedded as JSONB.
  regulation                      JSONB NOT NULL,
  -- Findings denormalised into tallyseal_oversight_finding; this
  -- column retains the canonical JSON shape for round-trip.
  findings                        JSONB NOT NULL DEFAULT '[]'::jsonb,
  -- Opaque extras for additive-MINOR field growth per ratchet #16.
  extras                          JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS tallyseal_oversight_tenant_idx ON tallyseal_oversight (tenant_id);
CREATE INDEX IF NOT EXISTS tallyseal_oversight_requirement_idx ON tallyseal_oversight (tenant_id, requirement_id);
CREATE INDEX IF NOT EXISTS tallyseal_oversight_conducted_idx ON tallyseal_oversight (conducted_at);
CREATE INDEX IF NOT EXISTS tallyseal_oversight_outcome_idx ON tallyseal_oversight (outcome);

CREATE TABLE IF NOT EXISTS tallyseal_oversight_finding (
  id                              TEXT PRIMARY KEY,
  oversight_id                    TEXT NOT NULL REFERENCES tallyseal_oversight(id) ON DELETE CASCADE,
  severity                        TEXT NOT NULL CHECK (severity IN ('low','medium','high','critical')),
  description                     TEXT NOT NULL,
  -- Optional evidence — array of EventIds tying findings to chain events.
  evidence_event_ids              TEXT[]
);
CREATE INDEX IF NOT EXISTS tallyseal_oversight_finding_oversight_idx ON tallyseal_oversight_finding (oversight_id);
CREATE INDEX IF NOT EXISTS tallyseal_oversight_finding_severity_idx ON tallyseal_oversight_finding (severity);
