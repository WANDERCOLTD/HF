-- Tallyseal prisma-adapter migration 0002 — add Warrant (primitive #10).
-- IMMUTABLE per ratchet #4. Forward-only; add another migration to evolve.
-- Tenant-scoped (tenant_id on every row). Idempotent via IF NOT EXISTS.

CREATE TABLE IF NOT EXISTS tallyseal_warrant (
  id                     TEXT PRIMARY KEY,
  tenant_id              TEXT NOT NULL,
  subject                TEXT NOT NULL,
  -- Issuer reference, embedded JSONB so the `IssuerRef` round-trip is
  -- byte-faithful (TCK fixture asserts this; lossy storage breaks
  -- signature verification against the recorded public key).
  issuer                 JSONB NOT NULL,
  issuer_id              TEXT NOT NULL,
  issuer_kind            TEXT NOT NULL CHECK (issuer_kind IN ('self','big-4','notified-body','mga','regulator','cloud','oem')),
  issuer_signature       TEXT NOT NULL,
  -- Regulation citations the warrant asserts authority over (array of
  -- RegulationCitation JSON objects).
  authority              JSONB NOT NULL DEFAULT '[]'::jsonb,
  -- WarrantScope { specs, regions?, classifications? } stored opaquely;
  -- adapter-level JSONB containment indexes support activeForSpec.
  scope                  JSONB NOT NULL,
  -- Denormalised array of spec keys for fast `activeForSpec` lookup
  -- without JSONB containment. Mirrors `scope.specs` exactly; the
  -- store writes both atomically.
  scope_specs            TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  issued_at              TIMESTAMPTZ NOT NULL,
  -- NULL = until-revoked (no expiry).
  expires_at             TIMESTAMPTZ,
  -- NULL = not revoked.
  revoked_at             TIMESTAMPTZ,
  revocation_reason      TEXT,
  -- WarrantRenewal opaque JSONB; NULL = renewal not tracked.
  renewal                JSONB,
  -- Opaque extras bag — runtime-extension fields not yet in the spec.
  -- Distinct from `payload` on events; matches the spec extensibility
  -- posture for additive-MINOR per ratchet #16.
  extras                 JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS tallyseal_warrant_tenant_idx ON tallyseal_warrant (tenant_id);
CREATE INDEX IF NOT EXISTS tallyseal_warrant_issuer_idx ON tallyseal_warrant (issuer_id);
CREATE INDEX IF NOT EXISTS tallyseal_warrant_expires_idx ON tallyseal_warrant (expires_at);
-- GIN on scope_specs for fast `activeForSpec` lookup (rewrite to b-tree
-- in pg-mem-shim test path; production uses GIN-on-text[]).
CREATE INDEX IF NOT EXISTS tallyseal_warrant_specs_idx ON tallyseal_warrant USING GIN (scope_specs);
