-- Tallyseal prisma-adapter migration 0005 — add Lineage (primitive #13).
-- IMMUTABLE per ratchet #4. Forward-only; add another migration to evolve.
-- Q-CR7 LOCKED 2026-05-22 (strict W3C PROV-O JSON-LD wire format).
-- The `prov_o` JSONB column carries the canonical PROV-O document
-- (round-trip byte-faithful); `canonical_hash` is the RFC 8785 JCS
-- SHA-256 over `prov_o` for federation-stable comparison across
-- CRAWCUS-conformant runtimes.
--
-- Query-ability trade-off (spec §7c surface): LineageEdge denormalisation
-- deferred to v0.2 opt-in.

CREATE TABLE IF NOT EXISTS tallyseal_lineage (
  id                    TEXT PRIMARY KEY,
  tenant_id             TEXT NOT NULL,
  -- The output event this records lineage for. NULL = pre-output
  -- recording (patched in later via subsequent event-link). FK NOT
  -- enforced because event-store + lineage may live in separate DBs
  -- in Y2 federation; canonical-hash is the integrity surface.
  output_event_id       TEXT,
  -- Affected data subjects (array of SubjectId) — appear in inputs.
  affected_subjects     TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  -- LineageInput[] stored opaquely; LineageEdge denormalisation is
  -- a v0.2 opt-in (spec §7c surface).
  inputs                JSONB NOT NULL DEFAULT '[]'::jsonb,
  -- ModelRef + PromptTemplateRef embedded as JSONB.
  model                 JSONB NOT NULL,
  prompt_template       JSONB,
  recorded_at           TIMESTAMPTZ NOT NULL,
  -- Q-CR7 LOCKED: full PROV-O JSON-LD document (round-trip byte-
  -- faithful via canonical hash). The wire format the audit-bundle
  -- composer reads verbatim.
  prov_o                JSONB NOT NULL,
  -- RFC 8785 JCS hash of prov_o for federation-stable comparison.
  -- Different runtimes (Rust / Go / JS) may store the PROV-O graph
  -- differently internally but the canonical hash matches.
  canonical_hash        TEXT NOT NULL,
  -- intent_id (FK to tallyseal_intent for the forIntent query path).
  -- FK NOT enforced for cross-DB federation tolerance (Y2 path).
  intent_id             TEXT NOT NULL,
  -- Opaque extras for additive-MINOR field growth per ratchet #16.
  extras                JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS tallyseal_lineage_tenant_idx ON tallyseal_lineage (tenant_id);
CREATE INDEX IF NOT EXISTS tallyseal_lineage_intent_idx ON tallyseal_lineage (tenant_id, intent_id);
CREATE INDEX IF NOT EXISTS tallyseal_lineage_output_event_idx ON tallyseal_lineage (output_event_id);
CREATE INDEX IF NOT EXISTS tallyseal_lineage_canonical_hash_idx ON tallyseal_lineage (canonical_hash);
