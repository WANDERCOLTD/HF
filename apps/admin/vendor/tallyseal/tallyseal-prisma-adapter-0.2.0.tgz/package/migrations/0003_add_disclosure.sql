-- Tallyseal prisma-adapter migration 0003 — add Disclosure +
-- DisclosureSignal (primitive #11; Q-CR9 LOCKED 2026-06-02).
-- IMMUTABLE per ratchet #4. Forward-only; add another migration to evolve.
--
-- Two tables — load-bearing structural separation per Q-CR9:
--   tallyseal_disclosure        — the delivered notice artifact
--   tallyseal_disclosure_signal — observational signals (read/click/dwell/replay)
--
-- Q-CR9 SIGNAL-not-gate canon: signals are NOT acknowledgments. The
-- two tables enforce the distinction at the storage layer — a signal
-- write CANNOT mutate Disclosure.acknowledged_at. The regression test
-- in disclosure-store.test.ts pins this.

CREATE TABLE IF NOT EXISTS tallyseal_disclosure (
  id                 TEXT PRIMARY KEY,
  tenant_id          TEXT NOT NULL,
  subject            TEXT NOT NULL,
  requirement_id     TEXT NOT NULL,
  -- DisclosureContent { text, format, locale } embedded as JSONB.
  content            JSONB NOT NULL,
  -- Locale denormalised for fast "has subject seen this requirement
  -- in their preferred language" lookups; mirrors content.locale.
  content_locale     TEXT NOT NULL,
  -- Hash of content (canonical-JSON + SHA-256). Tamper-evidence.
  content_hash       TEXT NOT NULL,
  delivered_at       TIMESTAMPTZ NOT NULL,
  delivery_method    TEXT NOT NULL CHECK (delivery_method IN ('in-app','email','sms','mail','api')),
  -- NULL until a DisclosureAcknowledged event references this id.
  acknowledged_at    TIMESTAMPTZ,
  -- NULL until a DisclosureRetracted event references this id.
  retracted_at       TIMESTAMPTZ,
  -- Opaque extras for additive-MINOR field growth per ratchet #16.
  extras             JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS tallyseal_disclosure_tenant_idx ON tallyseal_disclosure (tenant_id);
CREATE INDEX IF NOT EXISTS tallyseal_disclosure_subject_req_idx ON tallyseal_disclosure (tenant_id, subject, requirement_id);
CREATE INDEX IF NOT EXISTS tallyseal_disclosure_delivered_idx ON tallyseal_disclosure (delivered_at);

-- DisclosureSignal — structurally SEPARATE per Q-CR9. The
-- `signal_type` open-enum is stored as TEXT (not Postgres `enum`) so
-- additional values can ship via additive-MINOR per ratchet #16
-- without breaking changes. The CHECK constraint enumerates the day-1
-- locked values; future MINOR migrations widen the constraint via
-- forward migration (drop + recreate).
CREATE TABLE IF NOT EXISTS tallyseal_disclosure_signal (
  id                 TEXT PRIMARY KEY,
  tenant_id          TEXT NOT NULL,
  -- FK link to the Disclosure the signal was observed against. ON
  -- DELETE CASCADE: if the Disclosure is purged, signals about it are
  -- purged too (data-protection compliance — orphan signals leak
  -- inference about subjects).
  disclosure_id      TEXT NOT NULL REFERENCES tallyseal_disclosure(id) ON DELETE CASCADE,
  requirement_id     TEXT NOT NULL,
  -- Day-1 locked values per Q-CR9; widen via forward migration on additive-MINOR spec bumps.
  signal_type        TEXT NOT NULL CHECK (signal_type IN ('read','click','dwell','replay')),
  -- Hash of the Disclosure content the signal was observed against.
  -- MUST equal the delivered Disclosure's content_hash for the signal
  -- to count toward `pre.disclosureHasOpportunityToBeRead` (signal-on-
  -- stale-content does not satisfy the predicate per §6.A).
  content_hash       TEXT NOT NULL,
  observed_at        TIMESTAMPTZ NOT NULL,
  -- Optional view duration (ms) for 'dwell' / 'read' signals.
  view_ms            INTEGER,
  -- Free-form controller-extension bag per DisclosureSignalEvent.meta.
  meta               JSONB,
  -- Opaque extras for additive-MINOR field growth.
  extras             JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS tallyseal_disclosure_signal_tenant_idx ON tallyseal_disclosure_signal (tenant_id);
CREATE INDEX IF NOT EXISTS tallyseal_disclosure_signal_disclosure_idx ON tallyseal_disclosure_signal (disclosure_id);
CREATE INDEX IF NOT EXISTS tallyseal_disclosure_signal_req_idx ON tallyseal_disclosure_signal (requirement_id);
CREATE INDEX IF NOT EXISTS tallyseal_disclosure_signal_observed_idx ON tallyseal_disclosure_signal (observed_at);
