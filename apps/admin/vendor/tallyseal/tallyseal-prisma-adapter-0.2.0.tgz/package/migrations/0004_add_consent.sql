-- Tallyseal prisma-adapter migration 0004 — add Consent (primitive #12).
-- IMMUTABLE per ratchet #4. Forward-only; add another migration to evolve.
-- Kantara CR v1.1-compatible wire format. Per Q-CR6 LOCKED 2026-05-22
-- (Consent fully distinct from Warrant).
-- Per GDPR Art 7(3): adapters preserve withdrawn records (NOT a
-- delete-on-revoke pattern) — evaluator computes most-recent state.

CREATE TABLE IF NOT EXISTS tallyseal_consent (
  id                    TEXT PRIMARY KEY,
  tenant_id             TEXT NOT NULL,
  subject               TEXT NOT NULL,
  -- Who granted (usually = subject; differs for guardian-on-behalf).
  grantor               TEXT NOT NULL,
  requirement_id        TEXT NOT NULL,
  -- Granular processing purposes consented to (array of ProcessingPurpose).
  purposes              TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  -- RegulationCitation { framework, version, clause } embedded as JSONB.
  regulation            JSONB NOT NULL,
  granted_at            TIMESTAMPTZ NOT NULL,
  -- NULL until a ConsentRevoked event references this id. Preserved
  -- per GDPR Art 7(3): adapters MUST NOT delete revoked records.
  withdrawn_at          TIMESTAMPTZ,
  withdrawal_method     TEXT CHECK (withdrawal_method IS NULL OR withdrawal_method IN ('in-app','email','phone','mail','api','data-subject-portal')),
  -- ConsentReceipt (Kantara CR v1.1) embedded as JSONB for round-trip.
  receipt               JSONB NOT NULL,
  -- Opaque extras for additive-MINOR field growth per ratchet #16.
  extras                JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS tallyseal_consent_tenant_idx ON tallyseal_consent (tenant_id);
CREATE INDEX IF NOT EXISTS tallyseal_consent_subject_req_idx ON tallyseal_consent (tenant_id, subject, requirement_id);
CREATE INDEX IF NOT EXISTS tallyseal_consent_withdrawn_idx ON tallyseal_consent (withdrawn_at);
