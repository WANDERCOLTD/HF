# @tallyseal/ai-anthropic

Anthropic adapter for the Tallyseal `AIPort` — wraps `@anthropic-ai/sdk`
behind the neutral port interface so `@tallyseal/core` never imports
vendor types (C5 LOCKED: *neutral product, concentrated relationship*).

## Status

Y1 first-class per the `00-canon/architecture-primitives.md` AIPort
clause. Other vendor adapters (`@tallyseal/ai-openai`,
`@tallyseal/ai-vertex`, `@tallyseal/ai-bedrock`) cluster under
`@tallyseal/ai-*` and follow the same shape.

## Install

```sh
pnpm add @tallyseal/ai-anthropic @anthropic-ai/sdk
```

`@anthropic-ai/sdk` is a peer dependency — caller owns the client
construction (auth, base URL, residency endpoint).

## Usage

```ts
import Anthropic from '@anthropic-ai/sdk';
import { createAnthropicAdapter } from '@tallyseal/ai-anthropic';
import { writeEvent } from '@tallyseal/core';

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const aiPort = createAnthropicAdapter({ client });

// writeEvent + AIPort wire together via the runtime config — the
// adapter call shape is just `(req, ctx) => Promise<AIResponse>`.
const response = await aiPort.call(
  {
    model: 'claude-sonnet-4-6',
    prompt: 'Summarise this enrolment intake — [[pii:student-name]] applied...',
    promptTemplateVersion: 'enrolment.summary.v1',
    purpose: 'enrolment-decision',
    maxCostUsd: 0.05,
  },
  ctx, // TenantCtx — tenant + actor
);
```

The returned `AIResponse` carries `inputHash` / `outputHash` (SHA-256
of the tokenised prompt + raw model output) plus `latencyMs` /
`tokensIn` / `tokensOut` / `costUsd`. Downstream `writeEvent` attaches
these to the `EventAIProvenance` block on the event being committed,
making AI-mediated decisions audit-bundle-grade by construction.

## Cost cap enforcement

`AIRequest.maxCostUsd` is enforced **post-call** (Anthropic doesn't
expose a pre-flight token-count API for free-form prompts). If the
actual cost computed from response `usage` exceeds the cap, the
adapter throws `AIProxyRefusedError({reason: 'cost-cap-exceeded'})`.
The caller is responsible for committing an `AIProxyRefused` Event
into the chain so the refusal is auditable.

Pricing defaults to a 2026-05 snapshot of Anthropic public prices.
Override via the `pricing` option to track vendor pricing changes
without forking the adapter.

## Region strategy

`AIPort` adapters are expected to honour `ctx.tenant.region` for
residency. This adapter supports three strategies via the
`regionStrategy` option:

- `'pass-through'` (default) — adapter does not enforce region;
  caller owns residency by constructing the client against a
  region-appropriate endpoint.
- `'strict'` — refuses calls whose region is not in
  `acceptedRegions: Set<Region>`.
- `'custom'` — caller-provided `decide(region)` returns `'accept'`
  or `'refuse'`.

Refusals throw `AIProxyRefusedError({reason: 'region-not-supported'})`.

## Tool use / streaming

v0.1.0 implements the text-only `messages.create` path. Tool use,
streaming, and structured-output land in later versions as the
React adapter's `ToolCallApproval` integration matures.

## License

MIT.
