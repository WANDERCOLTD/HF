# `@tallyseal/spec-emitter`

> Pure-function CRAWCUS spec emitter with AST-level round-trip
> equivalence. Backs the Sprint E visual IntentSpec editor's
> PR-mode deploy path.

## What this is

Three pure functions:

| Function | Signature | What it does |
|---|---|---|
| `parse` | `(source: string) => EditableSpec` | TypeScript source → editor's data model |
| `emit` | `(spec: EditableSpec) => string` | Editor's data model → semi-canonical TypeScript source |
| `roundtripTest` | `(source: string) => RoundtripResult` | Verifies `parse(emit(parse(source))) ≡ parse(source)` at the babel AST level |

The contract the editor depends on:

> **`parse(emit(parse(source)))` is structurally equivalent to
> `parse(source)`** — the AST trees deep-equal after stripping source
> positions, ranges, location data, and Babel's `extra` metadata
> (raw token form / quote style of opaque-passthrough spans).

This is what makes the "compliance officer edits a label, opens a PR
against the customer repo" workflow trustworthy: the engineer
reviewing the PR can prove the change is exactly what the editor
described, with no silent drift in unrelated parts of the file.

## Semi-canonical emission

`emit` produces output with:

- **Deterministic top-level statement order** — header comments,
  imports, helper consts, `INTERNAL_FIELDS`, `defineCrawcusSpec(...)`.
- **Deterministic property order inside the spec object literal** —
  `key`, `projection`, `version`, `classification`, `i18nDefault`,
  `tags`, `fields`, `readiness`, `contracts`, then any unmodelled
  extras in their original order.
- **Deterministic chain order on fields** — base call → `.required()`
  / `.optional()` → `.label(…)` → `.askHint(…)` → opaque suffix
  (`.validates(…)`, `.defaultValue(…)`, `.contract(…)`, etc., preserved
  verbatim in their original order).
- **Two-space indentation, preserved quote-styles** matching the
  workspace prettier defaults.

## What this does NOT do

- **Does NOT pin a prettier version.** The output is structurally
  clean, but customer pre-commit hooks may re-prettify it on commit.
  Round-trip equivalence is at the AST level (positions + comments
  ignored), not the byte level.
- **Does NOT read customer `.prettierrc`.** The emitter is
  configuration-free — its job is to produce the structural shape,
  not to mimic the customer's house style. Aesthetics are the
  customer pre-commit's responsibility (per Sprint E 3-gate LOCKED (b)).
- **Does NOT model contracts structurally in v1.** Contract entries
  (whether `defineContract({…})` literals, factory calls like
  `humanOversight()`, or `…ageBand.adultOnly({…})` spreads) are
  preserved as verbatim source slices and rendered back unchanged.
  TKT-ADMIN-EDITOR-FIELDS (the next sprint ticket) only mutates field
  metadata + readiness predicates within the v1 template, so this
  opaque-passthrough behaviour is exactly what the editor needs.
- **Does NOT execute customer code.** Both `parse` and `emit` are
  pure string transformations — no `eval`, no `require`, no I/O.

## Opaque-source passthrough

Nodes the editor doesn't model structurally are preserved as
verbatim source slices and emitted back unchanged:

| Source span | Stored as | Notes |
|---|---|---|
| Import declarations | `EditableImport[]` (verbatim) | The editor doesn't add or remove imports in v1 |
| Helper consts (e.g., `EMAIL_PATTERN`, `INTAKE_KEY`) | `EditableExtraStatement[]` | Same as imports — passthrough |
| `INTERNAL_FIELDS` array | `EditableInternalFields` | Structurally modelled; editor can mutate the list |
| Contract entries within `pre` / `invariants` / `post` / `toolProposed` | `OpaqueSource[]` per phase | Editor surfaces the count + phase, but the body is opaque in v1 |
| Field chain methods beyond `.required` / `.optional` / `.label` / `.askHint` | concatenated `opaqueSuffix` string | `.validates`, `.defaultValue`, `.contract`, etc. |
| Readiness predicates beyond `({ has }) => has(field1, field2, …)` | `EditableReadiness.kind === 'opaque'` | TKT-ADMIN-EDITOR-READINESS limits v1 to the `allOf` template |
| Unmodelled spec keys (`extends`, `derogations`, `disclosureRequirements`, `consentRequirements`, `lineageRequirement`, `oversightRequirements`, `tools`, `customReducer`) | `EditableSpecProperty[]` | Passthrough in their original order |
| Trailing trivia after the spec | preserved `trailingTrivia` string | Trailing newlines / comments preserved |

This design is what makes the byte-equivalent AST round-trip a
single-pass guarantee — the emitter only has to be canonical for the
slices the editor actually modifies.

## Why this matters (Sprint E)

The Sprint E visual editor lets a PM / compliance officer mutate the
HF `EnrollmentIntake` spec (field labels, askHint copy, readiness
predicate fields, INTERNAL_FIELDS list) without going through the
3-day engineer round-trip the current PR workflow forces.

That's only safe if the emitted TS is **provably equivalent** to
hand-authored TS for the parts the editor didn't touch — otherwise
every editor save risks silently corrupting a contract definition or
import statement. The `roundtripTest` proof + the verbatim opaque
passthrough together provide that guarantee.

When the editor (TKT-ADMIN-EDITOR-FIELDS + TKT-ADMIN-EDITOR-READINESS
+ TKT-ADMIN-EDITOR-DEPLOY) ships, the deploy path will:

1. Read the customer's current spec source via the bridge
2. `parse(source)` to extract the EditableSpec
3. Apply the editor's mutations to the spec
4. `emit(editedSpec)` to produce the new source
5. `roundtripTest(emit(parse(originalSource)))` as a pre-flight
   sanity check (must equal true before opening the PR)
6. Hand the diffed source to `@tallyseal/admin-pr-adapter`, which
   opens a PR against the customer's repo

## Edge cases + known limits

| Limit | Workaround |
|---|---|
| Readiness predicates beyond `allOf(field[])` | Preserved as opaque; editor surfaces "Custom predicate — edit in TS" |
| Specs not matching the `export const Name = defineCrawcusSpec(…)` / `export default defineCrawcusSpec(…)` / `const Name = defineCrawcusSpec(…)` wrapper shapes | Throws `SpecParseError` — editor surfaces "This file's structure isn't editor-compatible; edit in TS" |
| Multiple `defineCrawcusSpec` calls in one file | Only the first is structurally extracted; subsequent calls preserved via trailing-trivia. Editor surfaces a warning |
| Comments inside the spec body | NOT preserved through round-trip on edited slices; preserved on opaque slices via verbatim source. The AST equality contract ignores comments by design |
| Non-RFC-5322 string escape sequences inside labels (`\u{…}`, raw template literals) | Preserved through round-trip via byte-faithful string emission with minimal escaping; complex unicode forms are normalised by Babel |

## Surface conditions (per ticket spec §6)

The implementation surfaces — does not silently choose — when any of
these conditions fire during integration:

- **(a)** Pure AST round-trip is impossible because `EditableSpec`
  carries metadata (e.g., source comments) that gets lost.
  **Resolution applied**: the round-trip contract is AST-level (after
  `stripPositions`), which explicitly ignores comments + position
  metadata. Comments inside the spec body are NOT preserved through
  edits — they ARE preserved through verbatim opaque slices. This is
  documented above + tested via the snapshot fixture.
- **(b)** A fixture exercises a CrawcusSpec API not yet covered by
  the emitter (e.g., `disclosureRequirements`, `consentRequirements`,
  `tools`). **Resolution applied**: the `extraSpecProperties` array
  captures unmodelled keys as opaque source. The Sprint E v1 editor
  doesn't surface them; future tickets can promote them to structured
  fields without breaking the contract.
- **(c)** `@babel/parser` version drift between this package and
  `@tallyseal/generator` causes inconsistent AST shape. **Resolution
  applied**: both packages declare `@babel/parser: "^7.29.3"` in
  their `dependencies` and consume the same workspace-resolved
  version via pnpm.

## License

MIT, per C3 Option D (Wide-OSS). Marked `private: true` for the
Sprint E development window — defensive scope claim per B1.3 spending
freeze. Publishing unfreezes when the founder lifts the freeze + the
Tailscale phonetic-adjacency caveat is cleared by attorney.

## Spec sources

- `docs/notebook/09-operating/tkt-admin-emitter-roundtrip-spec.md` —
  ticket spec
- `docs/notebook/02-product/sprint-e-visual-editor-design.md` —
  sprint design memo
- `docs/notebook/02-product/crawcus-format.md` — the format being
  emitted
- `docs/notebook/07-engineering/ratchet-disciplines.md` — engineering
  disciplines (zero-`any`, throw-only-typed-errors, etc.)
