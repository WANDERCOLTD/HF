# @tallyseal/prisma-adapter

Prisma-backed `EventStorePort` + default `ProjectionPort` + SQL
migrations for Tallyseal.

Per **Q6 LOCKED 2026-05-21 — Option A**: ships immutable SQL
migrations in `migrations/`, applied by a hand-rolled runner
(`applyMigrations(client)`); the customer's `schema.prisma` does NOT
need any Tallyseal model declarations — the adapter uses raw SQL
(`$queryRawUnsafe` / `$executeRawUnsafe`) against the tables our
migrations create.

## Install

```bash
pnpm add @tallyseal/prisma-adapter @tallyseal/core @prisma/client
```

## Setup — one-time

```ts
import { PrismaClient } from '@prisma/client';
import { applyMigrations } from '@tallyseal/prisma-adapter';

const prisma = new PrismaClient();
const result = await applyMigrations(prisma);
console.log(`Applied: ${result.applied.length}, skipped: ${result.skipped.length}`);
```

Or via the (future) CLI:

```bash
npx @tallyseal/generator migrate
```

Idempotent — safe to run on every deploy.

## Wire into `defineConfig`

```ts
import { defineConfig } from '@tallyseal/core';
import { PrismaEventStore, PrismaNoopProjection } from '@tallyseal/prisma-adapter';

const prisma = new PrismaClient();

export default defineConfig({
  eventStore: new PrismaEventStore(prisma),
  projection: new PrismaNoopProjection(),
  // ... other ports
});
```

## Same-transaction guarantee (ratchet #13)

`PrismaEventStore.begin(tenant, fn)` opens a `client.$transaction(...)`.
Inside the callback, `tx.__tx.raw` is the Prisma transaction client
— customer's per-intent reducers (registered via
`defineProjection({...})`) get this through `ReducerCtx.tx`. The
event append + the projection write commit atomically.

## Atomic Event+projection writes (`writeEventWithProjection`)

For the common case where intake-flow code emits an Event AND wants
to write a typed-table projection (Warrant / Disclosure / DisclosureSignal /
Consent / HumanOversight / OversightFinding) in lockstep, use the
`writeEventWithProjection` helper. It opens ONE Prisma `$transaction`
and writes both atomically — either both commit or neither does.

```ts
import {
  writeEventWithProjection,
  type ProjectionWrite,
} from '@tallyseal/prisma-adapter';
import { computeContentHash } from '@tallyseal/crawcus-spec';

// 1. Build the Event (caller computes contentHash + prevHash).
const event = makeDisclosureDeliveredEvent(/* ... */);

// 2. Build the projection record.
const disclosure: Disclosure = {
  id: 'dsc_001' as DisclosureId,
  tenantId,
  subject,
  requirementId: 'gdpr-art-13-notice' as DisclosureRequirementId,
  content: { text: 'We process your data ...', format: 'text', locale: 'en' },
  contentHash: 'h_v1' as ContentHash,
  deliveredAt: '2026-06-05T00:00:00.000Z' as Timestamp,
  deliveryMethod: 'in-app',
  acknowledgedAt: null,
  retractedAt: null,
};

// 3. Atomically write both inside one transaction.
const result = await writeEventWithProjection({
  event,
  projection: { kind: 'disclosure', record: disclosure },
  client: prisma,
});
// → result.event === event; result.projection === disclosure
```

### Discriminator values

| `kind` | Writes to | Record shape |
|---|---|---|
| `'warrant'` | `tallyseal_warrant` | `Warrant` |
| `'disclosure'` | `tallyseal_disclosure` | `Disclosure` |
| `'disclosure-signal'` | `tallyseal_disclosure_signal` | `RecordSignalInput` |
| `'consent'` | `tallyseal_consent` | `Consent` |
| `'oversight-requirement'` | `tallyseal_oversight` (+ findings) | `HumanOversight` |
| `'oversight-finding'` | `tallyseal_oversight_finding` | `RecordOversightFindingInput` |

### Q-CR9 SIGNAL-not-gate (LOAD-BEARING)

`'disclosure'` and `'disclosure-signal'` are SEPARATE discriminator
values — they write to SEPARATE tables. A `'disclosure-signal'` write
CANNOT mutate `tallyseal_disclosure.acknowledged_at`. This preserves
the Q-CR9 structural separation at the helper layer (defence-in-depth
on top of the schema-layer separation in
`migrations/0003_add_disclosure.sql`). Pinned by a regression test in
`test/write-event-with-projection.test.ts`.

### Atomicity — both writes or neither

If the projection insert throws (e.g., unique-constraint violation),
the entire transaction rolls back — the Event is NOT committed to the
chain. Conversely, if the Event append throws (e.g., monotonic-version
collision), the projection is NOT committed. No partial state is
structurally reachable.

### Lineage is intentionally absent

Lineage auto-records via `writeEvent` per Q-CR7 — it doesn't fit the
"caller specifies projection" pattern. Use the standard `writeEvent`
path for Lineage.

## Row mappers

Pure row → runtime mappers for read paths (`apps/admin-bridge` callbacks, customer queries):

| Helper | Maps | From |
|---|---|---|
| `rowToEvent(row)` | `Event` | `TallysealEventRow` (canonical `tallyseal_event` row) |
| `rowToIntent(row)` | `Intent` | `TallysealIntentRow` (canonical `tallyseal_intent` row) |

Use the brand-cast typed-id shape — the helpers return values structurally assignable to `IntentId` / `TenantId` / `IntentKey` without further casting.

## Tables created

| Table | Purpose | Migration |
|---|---|---|
| `tallyseal_event` | Append-only event log; UUIDv7 IDs; UNIQUE(intent_id, version); GIN index on data_subject_ids for DSAR | 0001 |
| `tallyseal_intent` | Intent runtime state + accumulated snapshot | 0001 |
| `tallyseal_suggestion` | Suggestion lifecycle records (Art. 14 surface) | 0001 |
| `tallyseal_warrant` | Warrant primitive #10 — authority-to-claim records | 0002 |
| `tallyseal_disclosure` | Disclosure primitive #11 — delivered notice artefacts | 0003 |
| `tallyseal_disclosure_signal` | Q-CR9 SIGNAL-not-gate — observational signals, SEPARATE from `tallyseal_disclosure` | 0003 |
| `tallyseal_consent` | Consent primitive #12 — Kantara CR v1.1; revoked records preserved per GDPR Art 7(3) | 0004 |
| `tallyseal_lineage` | Lineage primitive #13 — W3C PROV-O JSON-LD round-tripped byte-faithful | 0005 |
| `tallyseal_oversight` | HumanOversight primitive #14 — conducted-review records | 0006 |
| `tallyseal_oversight_finding` | HumanOversight findings (1:N from `tallyseal_oversight`, ON DELETE CASCADE) | 0006 |
| `_tallyseal_migrations` | Internal: applied-migration ledger with SHA-256 checksums | (bootstrap) |

All tables are prefixed `tallyseal_` to avoid collisions; all carry
`tenant_id` + index. Partitioning is an adapter optimisation
deferred to S1 load testing.

A read-only Prisma model fragment mirroring these tables ships at
`prisma/tallyseal-models.prisma` — see §"Prisma schema integration"
below.

## Prisma schema integration — read-only typegen fragment

Per **TKT-HF-PRISMA-SCHEMA** (HF upstream ask 2026-06-18): the adapter
ships a `tallyseal-models.prisma` fragment at
`packages/prisma-adapter/prisma/tallyseal-models.prisma` (resolvable
via the `./prisma/tallyseal-models.prisma` sub-export). Every model
carries `@@ignore` — Prisma typegen sees the table TYPES (so
downstream coverage tests + lattice surveys can assert against the
schema) but no `.create()` / `.update()` / `.delete()` Client methods
are generated. **The MUTATION surface stays raw-SQL inside this
adapter** (ratchet #13 sealed-mutation discipline).

### Why @@ignore (load-bearing)

Generating writable Prisma models for `tallyseal_*` would open
mutation paths (`prisma.tallysealEvent.create()`,
`prisma.tallysealDisclosure.update()`, etc.) that bypass the
hash-chain integrity + Q-CR9 SIGNAL-not-gate invariants enforced
inside `writeEvent` / `recordWarrant` / `recordDisclosure` /
`recordDisclosureSignal` / `recordConsent` / `recordOversight` /
`writeEventWithProjection`. That would silently violate ratchet #13.
The structural `@@ignore` mitigation was locked 2026-06-18 (HF
confirmed: "structural beats convention").

### How to include from a customer `schema.prisma`

Prisma 5.15+ ships a `prismaSchemaFolder` preview feature that treats
every `.prisma` file in the schema folder as part of a single schema.
Recommended pattern:

```prisma
// customer/prisma/schema.prisma
generator client {
  provider        = "prisma-client-js"
  previewFeatures = ["prismaSchemaFolder"]
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

// ... customer models ...
```

Then place a vendored copy of `tallyseal-models.prisma` at
`customer/prisma/tallyseal-models.prisma`. The Prisma CLI picks it
up automatically. Refresh on each `@tallyseal/prisma-adapter` upgrade
via a `fetch:tallyseal-models` script (see HF heads-up doc for the
recipe).

Without the preview feature, customers may copy the model
declarations into their `schema.prisma` directly. The drift-detection
test below catches divergence.

### Drift detection

```bash
pnpm --filter @tallyseal/prisma-adapter test:schema-drift
```

Parses every `migrations/000?_*.sql` + parses
`prisma/tallyseal-models.prisma` + asserts:

- Every `tallyseal_*` SQL table has a Prisma model with matching
  `@@map`.
- Every Prisma model maps to an actual SQL table (no phantoms).
- Every raw-SQL column is covered (via `@map` or snake_case fallback).
- Every model carries `@@ignore` (ratchet #13 sealed-mutation guard).
- `TallysealDisclosure` and `TallysealDisclosureSignal` are SEPARATE
  models (Q-CR9 SIGNAL-not-gate guard).

CI fails the PR on any drift.

## Migrations are immutable (ratchet #4)

Migrations in `migrations/` are forward-only. The runner records a
SHA-256 checksum of each file when applied. If a previously-applied
file is later edited, the runner REFUSES on next run with a clear
error — never silently re-applies.

To change schema after release: add a NEW forward migration with a
higher numeric prefix. Never edit historical files.

## Replacing in-memory session-store

If you've been keeping intake-flow events in a process-local
`session-store.ts` (`Map<intentId, Event[]>` keyed in memory),
`PrismaEventStore` is the drop-in durable replacement. Persists every
appended `Event` to `tallyseal_event` with the hash chain intact —
restart-safe, tamper-evident, audit-bundle ready.

```ts
import { PrismaClient } from '@prisma/client';
import { computeContentHash, GENESIS_PREV_HASH, type Event } from '@tallyseal/core';
import {
  applyMigrations,
  PrismaEventStore,
} from '@tallyseal/prisma-adapter';

const prisma = new PrismaClient();
await applyMigrations(prisma); // idempotent; safe on every deploy

const store = new PrismaEventStore(prisma);

// Append an event — caller computes contentHash + prevHash via the
// CRAWCUS canonical pipeline. Genesis uses GENESIS_PREV_HASH (null).
const { id: _id, contentHash: _ch, ...hashable } = candidateEvent;
const event: Event = {
  ...candidateEvent,
  contentHash: computeContentHash(hashable),
};

await store.begin(tenant, async (tx) => {
  await store.append(event, tx);
});

// Read back in append order.
const replayed: Event[] = [];
for await (const e of store.read(event.intentId)) replayed.push(e);
```

### Verify conformance with `@tallyseal/crawcus-tck`

The CRAWCUS hash-chain primitive ships a drop-in contract — runtime-
agnostic, no Prisma required. Adopters writing integration tests
against their host's `PrismaEventStore` wiring should mirror the
following shape:

```ts
import {
  runHashChainContract,
  TCK_RESULT_PASS,
  type HashChainContractStore,
} from '@tallyseal/crawcus-tck';
import type { Event, IntentId } from '@tallyseal/core';
import { PrismaEventStore } from '@tallyseal/prisma-adapter';

// Adapt the full EventStorePort surface (begin/append/read/chain) down
// to the minimal HashChainContractStore the TCK drives.
function adapt(store: PrismaEventStore, tenant: Tenant): HashChainContractStore {
  return {
    async appendEvent(event: Event) {
      await store.begin(tenant, async (tx) => store.append(event, tx));
      return event;
    },
    async readChain(intentId: IntentId) {
      const events: Event[] = [];
      for await (const e of store.read(intentId)) events.push(e);
      return events;
    },
  };
}

test('PrismaEventStore satisfies the hash-chain contract', async () => {
  const result = await runHashChainContract({
    storeFactory: () => adapt(new PrismaEventStore(prisma), tenant),
    intentId: 'test-intent-001' as IntentId,
  });
  expect(result).toBe(TCK_RESULT_PASS);
});
```

The equivalent assertion runs in this package's own
`test/hash-chain-conformance.test.ts` against the in-process
`MockPrismaClient`; consult that file for the full reference shape.

### Clean-cutover, no migration

If your old in-memory chain doesn't survive process restarts (intake
sessions are ephemeral), drop the old store wholesale on next deploy.
New sessions start fresh on `PrismaEventStore.writeEvent`; there is no
hash-version cutover to manage because in-flight sessions are
already lost on each redeploy under the previous regime. See
[HF Phase 1.5 adoption playbook](https://github.com/tallyseal/tallyseal/blob/main/docs/notebook/08-design-partner/hf-phase-1-5-prisma-event-store-adoption-20260618.md)
for the worked example.

## Status

v0.4.0 — adds read-only Prisma schema fragment + drift-detection CI
step per TKT-HF-PRISMA-SCHEMA (HF wedge customer upstream ask
2026-06-18). Builds on v0.2.0 (primitives 10-14 stores —
Warrant / Disclosure + DisclosureSignal / Consent / Lineage /
HumanOversight per TKT-PRISMA-ADAPTER-PRIMITIVES-10-14),
`rowToIntent` mapper (TKT-PRISMA-ROW-TO-INTENT), and
`writeEventWithProjection` atomic helper
(TKT-WRITE-EVENT-WITH-PROJECTION). Integration tested against pg-mem
+ mutation-tested via Stryker per ratchet #2.

## License

MIT.
