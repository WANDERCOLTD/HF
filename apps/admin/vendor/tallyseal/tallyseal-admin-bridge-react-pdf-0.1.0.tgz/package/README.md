# @tallyseal/admin-bridge-react-pdf

Reference `PdfRendererPort` adapter for [`@tallyseal/admin-bridge`](../admin-bridge/),
backed by [`@react-pdf/renderer`](https://react-pdf.org/). Renders an
[`AuditBundle`](../crawcus-spec/) to PDF bytes for the
`GET /tallyseal-bridge/intent/:id/bundle.pdf` endpoint.

## Why a separate package

`@tallyseal/admin-bridge` exports the `PdfRendererPort` interface
(renderer-agnostic). This package implements it against
`@react-pdf/renderer` — a React-component-based PDF library that adds
~2MB of transitive deps. Shipping the adapter separately preserves the
**Q-ADMIN-FEDERATION-OEM motion**:

- HF + admin-viewer dogfood install both packages, wire
  `pdfRenderer: createReactPdfRenderer()`.
- OEM embedders (sector-pack vendors, Big-4 consultancies) install only
  `@tallyseal/admin-bridge` and implement `PdfRendererPort` against
  whatever stack they prefer (puppeteer / playwright / pdfkit /
  handwritten) — no 2MB transitive forced into the bridge core.

Per HF 2026-06-18 LOCKED: explicit injection at the route-handler
boundary; no auto-wire-when-installed. Matches the uniform DI contract
the bridge uses for `bundleSource`, `intentLister`, `accessRecorder`.

## Install

```bash
pnpm add @tallyseal/admin-bridge @tallyseal/admin-bridge-react-pdf
# Peer deps you already have if you ship a React UI:
pnpm add react @react-pdf/renderer
```

## Use

```ts
import { createBridgeRouter } from '@tallyseal/admin-bridge';
import { createReactPdfRenderer } from '@tallyseal/admin-bridge-react-pdf';

const router = createBridgeRouter({
  // ... your bundleSource + intentLister + accessRecorder + auth + scope config ...
  pdfRenderer: createReactPdfRenderer(),
});
```

### Optional title

```ts
createReactPdfRenderer({ title: 'My Compliance Report' });
```

That's the entire surface. v0.1.0 deliberately ships one knob; if you
need more layout control, implement `PdfRendererPort` directly and use
this package as a reference.

## Output shape

One-page A4 PDF with the following blocks (omitted when the
corresponding section is absent on the bundle):

| Block | Content |
|---|---|
| Header | Bundle title + tenant + intent + bundle version + `generatedAt` |
| Intent | Key, spec version, classification, state |
| Compliance manifest | Each entry as a label/value row |
| Events | Per-event row: timestamp · kind · actor.id |
| Hash-chain proof | Root hash + chain length + from/to event ids |
| Contract evaluations | Per-result: contract id · pass/fail · severity (if fail) |
| Warrants | Per-warrant: id · issuer.id · (revoked) if applicable |
| Disclosures | Per-disclosure: id · subject · delivery method |
| Consents | Per-consent: id · subject · active/withdrawn |
| Lineages | Per-lineage: id · model.id · input count |
| Oversights | Per-oversight: id · outcome · overseer.id |
| Footer | Adapter name + bundle version |

## Determinism

`@react-pdf/renderer` embeds a `/CreationDate` in the PDF trailer; this
adapter does NOT attempt byte-equivalence across renders. If you need
deterministic PDFs (e.g., for auditor-signable artifacts), use
[`@tallyseal/verifier`](../verifier/)'s zero-dep
`renderPdf(VerifyResult)` instead — it ships the auditor-signable
report shape with a deterministic trailer derived from
`result.verifiedAt`.

## Errors

Renderer errors propagate. The bridge does not swallow them — surface
conditions during PDF generation are real bugs, not graceful-degrade
paths. The bridge logs + returns 500 to the caller.

## License

MIT under [C3 Option D (Wide-OSS)](../../docs/notebook/00-canon/business-model.md).
No `@tallyseal/cloud-*` dependency.

## Spec

- `docs/notebook/09-operating/tkt-hf-admin-bridge-finish-spec.md` §3
- `docs/notebook/08-design-partner/hf-ask-5-admin-bridge-finish-20260618.md`
- HF wiring LOCKED 2026-06-18 — explicit injection.
