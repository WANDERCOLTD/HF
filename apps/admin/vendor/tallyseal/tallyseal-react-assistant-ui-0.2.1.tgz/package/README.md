# @tallyseal/react-assistant-ui

Audit-grade compliance surface for [assistant-ui](https://www.assistant-ui.com/)
chat. Wraps the seven Tallyseal headless hooks from `@tallyseal/react`
into drop-in React components that bind to assistant-ui's
`<Thread>` / `<Composer>` / `<Message>` render tree per
[Q9 LOCKED §1 ownership table](../../docs/notebook/01-strategy/q9-assistant-ui-posture.md).

## Status

v0.1.0 — the marquee adapter per [Sprint B1](../../docs/notebook/HANDOFF-NEXT-SESSION.md).
Wraps the six rendering-bearing hooks (Banner / SuggestionRail /
ActivityTray / ReadinessGate / IntentForm / ToolCallApproval) +
exports a `<TallysealAssistantUI>` composite for the default
layout.

## Install

```sh
pnpm add @tallyseal/react-assistant-ui @assistant-ui/react react react-dom
```

`@assistant-ui/react`, `react`, and `react-dom` are peer
dependencies — caller owns version selection.

## The Q9 differentiator

`<TallysealToolCallApproval>` requires an **Article-6 LawfulBasis at
approve-time**. The picked basis travels onto the resulting
`SuggestionAccepted` event via the `useToolCallApproval` hook's
`onApprove(suggestion, lawfulBasis)` signature. Downstream
audit-bundle composition can then surface *why* the operator approved
each tool call — not just *that* they did.

This is the structural distinction from generic assistant-ui tool-UI
approval (which is yes/no with no compliance binding).

## Usage — default composite layout

```tsx
import { TallysealAssistantUI } from '@tallyseal/react-assistant-ui';
import { Thread } from '@assistant-ui/react';

function EnrolmentChat({ spec, events, suggestions, values }) {
  return (
    <TallysealAssistantUI
      spec={spec}
      events={events}
      suggestions={suggestions}
      values={values}
      onSuggestionAccept={(s) => writeEvent({ kind: 'SuggestionAccepted', ... })}
    >
      <Thread />
    </TallysealAssistantUI>
  );
}
```

The composite arranges:

```
┌─────────────────────────────────────────┐
│ TallysealBanner                         │  blocking/warning compliance prompts
├──────────────────────────┬──────────────┤
│ TallysealSuggestionRail  │              │  proposed chips above composer
├──────────────────────────┤  Activity    │
│ TallysealReadinessGate   │   Tray       │  gates send until required fields filled
│   <Thread> from           │              │  newest-first event stream
│   @assistant-ui/react)   │              │
└──────────────────────────┴──────────────┘
```

## Usage — composing primitives directly

For non-default layouts, import the per-component primitives:

```tsx
import {
  TallysealBanner,
  TallysealSuggestionRail,
  TallysealActivityTray,
  TallysealReadinessGate,
  TallysealToolCallApproval,
  TallysealIntentForm,
} from '@tallyseal/react-assistant-ui';
```

Each component is a thin render of its corresponding
`@tallyseal/react` hook with semantic DOM + `data-tallyseal="..."`
attributes for styling. No CSS shipped — consumers style via CSS
targeting the data-attributes.

## Tool approval — integrating with assistant-ui's ToolUI

`<TallysealToolCallApproval>` is shape-compatible with assistant-ui's
`makeAssistantToolUI` render prop:

```tsx
import { makeAssistantToolUI } from '@assistant-ui/react';
import { TallysealToolCallApproval } from '@tallyseal/react-assistant-ui';

const EnrollStudentApproval = makeAssistantToolUI<EnrollArgs, EnrollResult>({
  toolName: 'enroll_student',
  render: ({ args, status, addResult }) => (
    <TallysealToolCallApproval
      suggestion={suggestionFromArgs(args)}
      toolName="enroll_student"
      onApprove={(s, basis) => {
        // Commit a SuggestionAccepted Event with basis on the chain,
        // then signal assistant-ui to proceed.
        writeEvent({ kind: 'SuggestionAccepted', payload: { lawfulBasis: basis, ... } });
        addResult({ approved: true });
      }}
      onDecline={(s, reason) => addResult({ approved: false, reason })}
    />
  ),
});
```

## License

MIT.
