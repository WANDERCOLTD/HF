# @tallyseal/admin-bridge

> Push-mode adapter that exposes read-only inspection endpoints from your
> Tallyseal-instrumented runtime to the `apps/admin-viewer/` UI. MIT.
> Customer DB stays customer's; viewer never holds your data.

[Sprint D design memo](https://github.com/tallyseal/tallyseal/blob/main/docs/notebook/02-product/sprint-d-admin-viewer-design.md)
· [TKT-ADMIN-BRIDGE-1 spec](https://github.com/tallyseal/tallyseal/blob/main/docs/notebook/09-operating/tkt-admin-bridge-1-spec.md)

---

## What this is

`@tallyseal/admin-bridge` is the **customer-installed** side of the
Tallyseal admin viewer split. You install this package in your runtime
(Next.js / Hono / Express), wire your existing `EventStorePort` +
`ProjectionPort`, configure scopes + auth, and mount the router at a
known URL. Operators run the separate `apps/admin-viewer/` UI and point
it at your bridge over HTTPS.

- **Push-only** — your database stays yours; the viewer never persists
  customer data. Every render is a fresh bridge call.
- **Read-only** — only `GET` is implemented; the bridge cannot mutate.
- **MIT** — self-hostable. No `@tallyseal/cloud-*` dependency.
- **Auditable** — every authenticated request emits a `BridgeAccessEvent`
  into your event store. Inspection IS an event in the chain.
- **Default-DENY scope filter** — per-intent allow-list of roles +
  sections; everything else is rejected with 403.

## What this is NOT

- Not an admin-side database. The viewer holds no customer data.
- Not a write path. Bridge endpoints are all `GET`.
- Not a federation gateway. Single-tenant install per customer runtime.
- Not a hosted service. (`cloud.tallyseal.dev` is a separate, paid scope.)
- Not a replacement for the CLI. Every bridge endpoint has a CLI peer
  (`crawcus-verify`, `audit-bundle`, `dsar export`, `eval`).

## Quickstart (Next.js App Router)

Install:

```bash
pnpm add @tallyseal/admin-bridge @tallyseal/core @tallyseal/crawcus-spec jose
```

Create `app/api/tallyseal-bridge/[...slug]/route.ts`:

```ts
import { NextRequest } from 'next/server';
import {
  createBridgeRouter,
  bridgeAuthFromOidc,
  toNextRouteHandler,
} from '@tallyseal/admin-bridge';
import { eventStore, projection } from '@/lib/tallyseal';
import { bundleSource, intentLister, accessRecorder } from '@/lib/admin-bridge-wiring';

const router = createBridgeRouter({
  eventStore,
  projection,
  authVerify: bridgeAuthFromOidc({
    jwksUri: process.env.CLERK_JWKS_URL!,
    audience: 'tallyseal-admin-bridge',
  }),
  intentScopes: {
    defaultPolicy: 'deny',
    perIntent: {
      EnrollmentIntake: {
        allowedRoles: ['compliance-officer'],
        allowedSections: [
          'events',
          'warrants',
          'disclosures',
          'consents',
          'lineages',
          'oversights',
          'bundle-jsonld',
          'bundle-pdf',
        ],
      },
    },
  },
  bundleSource,
  intentLister,
  accessRecorder,
});

const handler = toNextRouteHandler(router, { mountPoint: '/api/tallyseal-bridge' });

export const GET = handler;
```

`bundleSource`, `intentLister`, and `accessRecorder` are small adapters
you write against your existing projections + `writeEvent` path. See
the [Wiring guide](#wiring-the-customer-side-adapters) below.

## Quickstart (Hono)

```ts
import { Hono } from 'hono';
import { createBridgeRouter, toHonoRouter } from '@tallyseal/admin-bridge';

const router = createBridgeRouter({ ... });
const bridge = toHonoRouter(router);

const app = new Hono();
app.get('/api/tallyseal-bridge/*', (c) => bridge(c, '/api/tallyseal-bridge'));
```

## Quickstart (Express)

```ts
import express from 'express';
import { createBridgeRouter, toExpressMiddleware } from '@tallyseal/admin-bridge';

const router = createBridgeRouter({ ... });
const app = express();
app.use('/api/tallyseal-bridge', toExpressMiddleware(router));
```

## Endpoints

| Method | Path | Auth | Returns |
|---|---|---|---|
| `GET` | `/intents?since=&until=&subjectId=&actor=&limit=` | required | Paginated intent summaries |
| `GET` | `/intent/:id/events` | required | Full event chain + hash-chain proof |
| `GET` | `/intent/:id/bundle` | required | `composeAuditBundle()` JSON-LD (PROV-O context) |
| `GET` | `/intent/:id/bundle.pdf` | required | PDF report (501 if no renderer wired) |
| `GET` | `/health` | optional | Version + capabilities + scope summary |

Every authenticated request emits a `BridgeAccessEvent` into your event
store via the `accessRecorder` you wire. Cross-tenant attempts return
403; scope violations return 403; missing intents return 404.

### Curl examples

```bash
# Health probe (no auth)
curl https://example.com/api/tallyseal-bridge/health

# List intents
curl -H "Authorization: Bearer $TOKEN" \
  "https://example.com/api/tallyseal-bridge/intents?since=2026-01-01"

# Full event chain
curl -H "Authorization: Bearer $TOKEN" \
  https://example.com/api/tallyseal-bridge/intent/i_abc/events

# Bundle JSON-LD
curl -H "Authorization: Bearer $TOKEN" \
  -H "Accept: application/ld+json" \
  https://example.com/api/tallyseal-bridge/intent/i_abc/bundle

# Bundle PDF (requires renderBundlePdf wired)
curl -H "Authorization: Bearer $TOKEN" \
  -o bundle.pdf \
  https://example.com/api/tallyseal-bridge/intent/i_abc/bundle.pdf
```

## Auth recipes

### OIDC (production)

`bridgeAuthFromOidc({ jwksUri, audience })` verifies a JWT against your
IdP's JWKS endpoint + maps standard claims onto a `BridgeActor`.

Default claim map (Clerk + WorkOS conventions):

| BridgeActor field | JWT claim |
|---|---|
| `id` | `sub` |
| `orgId` | `org_id` |
| `role` | `tallyseal_role` |
| `name` | `name` |

`role` must be a value from the canon-closed `OverseerRole` union from
`@tallyseal/crawcus-spec` (`individual` · `committee` · `rotation` ·
`compliance-officer` · `ethics-board` · `notified-body`). Any other
value fails with `missing-claims` and the request is rejected with 401.

Override the claim map for non-default IdPs:

```ts
bridgeAuthFromOidc({
  jwksUri: 'https://your-tenant.auth0.com/.well-known/jwks.json',
  audience: 'tallyseal-admin-bridge',
  claimMap: {
    id: 'sub',
    orgId: 'https://tallyseal.dev/claims/org_id',
    role: 'https://tallyseal.dev/claims/role',
    name: 'name',
  },
});
```

Examples by IdP:

- **Clerk**: `jwksUri = 'https://<app>.clerk.accounts.dev/.well-known/jwks.json'`; the `org_id` + `name` claims ship natively. Add `tallyseal_role` via a JWT template.
- **Auth0**: `jwksUri = 'https://<tenant>.auth0.com/.well-known/jwks.json'`; use a namespaced custom claim for `role` + `org_id` via a Post-Login Action.
- **WorkOS**: `jwksUri = 'https://api.workos.com/sso/jwks/<client_id>'`; configure org metadata to flow `org_id`.

### Static-key (dev mode only)

`bridgeAuthFromStaticKey({ secret, actor })` accepts a bearer secret.

> **`[@tallyseal/admin-bridge] bridgeAuthFromStaticKey is DEV-MODE ONLY**
> **— production deployments MUST use bridgeAuthFromOidc against a customer**
> **IdP. The bridge access endpoint should never be reachable from the public**
> **internet while configured with a static secret.`**

The warning text above is emitted to `console.warn` the first time the
hook is invoked in a process. Use only for local demos. Production
must use the OIDC hook.

## Scope config — worked HF-style example

The Sprint D dogfood customer (HF) installs the bridge with one intent
kind (`EnrollmentIntake`) accessible to one role
(`compliance-officer`), with four sections:

```ts
{
  defaultPolicy: 'deny',
  perIntent: {
    EnrollmentIntake: {
      allowedRoles: ['compliance-officer'],
      allowedSections: [
        'events',          // chain-of-custody view
        'disclosures',     // GDPR Art 13/14 disclosures + Q-CR9 signals
        'consents',        // Art 6 lawful-basis trail
        'bundle-jsonld',   // download for offline review
      ],
    },
  },
}
```

A second role (`ethics-board`) only sees `'events'`:

```ts
{
  defaultPolicy: 'deny',
  perIntent: {
    EnrollmentIntake: {
      allowedRoles: ['compliance-officer'],
      allowedSections: ['events', 'disclosures', 'consents', 'bundle-jsonld'],
    },
    EnrollmentIntake_audit: {  // different intent kind for the read-only role
      allowedRoles: ['ethics-board'],
      allowedSections: ['events'],
    },
  },
}
```

The wildcard `'*'` key (use sparingly) applies to intent kinds with no
specific entry — a specific entry always shadows the wildcard.

## Wiring the customer-side adapters

The bridge stays runtime-agnostic by accepting four customer-side
callbacks:

### `bundleSource: BridgeBundleSource`

The bridge composes the audit bundle via
`composeAuditBundle()` from `@tallyseal/core`, but the primitives 10–14
(Warrants / Disclosures / Consents / Lineages / Oversights) live in
your projections, not the existing core ports. You write a small
adapter that hands the bridge the required inputs:

```ts
const bundleSource: BridgeBundleSource = {
  async load(intentId) {
    const intent = await prisma.intent.findUnique({ where: { id: intentId } });
    if (!intent) return null;
    const events = await prisma.event.findMany({ where: { intentId } });
    const chainProof = await eventStore.chain(intentId);
    const spec = registry.lookup(intent.specKey);
    const compliance = registry.compliance(intent.specKey);
    return {
      tenant: { id: intent.tenantId, region: 'eu-west-1' },
      intent,
      spec,
      compliance,
      events,
      chainProof,
      warrants: await prisma.warrant.findMany({ where: { intentId } }),
      disclosures: await prisma.disclosure.findMany({ where: { intentId } }),
      consents: await prisma.consent.findMany({ where: { intentId } }),
      lineages: await prisma.lineage.findMany({ where: { intentId } }),
      oversights: await prisma.oversight.findMany({ where: { intentId } }),
    };
  },
};
```

### `intentLister: BridgeIntentLister`

Aggregate `/intents` query:

```ts
const intentLister: BridgeIntentLister = {
  async list({ since, until, subjectId, actor, limit }) {
    const intents = await prisma.intent.findMany({
      where: {
        ...(since && { createdAt: { gte: since } }),
        ...(until && { createdAt: { lte: until } }),
      },
      take: limit,
      orderBy: { updatedAt: 'desc' },
    });
    return intents.map((i) => ({
      id: i.id,
      key: i.key,
      state: i.state,
      createdAt: i.createdAt,
      updatedAt: i.updatedAt,
      subjectCount: i.dataSubjectIds?.length ?? 0,
    }));
  },
};
```

### `accessRecorder: BridgeAccessRecorder`

Append the `BridgeAccessEvent` to your event store. Use your existing
`writeEvent` path so hash chaining stays canonical:

```ts
const accessRecorder: BridgeAccessRecorder = {
  async record({ actor, intentId, payload }) {
    await writeEvent({
      tenantId: actor.orgId,
      intentId: intentId ?? GLOBAL_BRIDGE_INTENT_ID,
      kind: BRIDGE_ACCESS_EVENT_KIND,
      payload,
      actor: { id: actor.id, kind: 'human', displayName: actor.name },
      lawfulBasis: 'legal-obligation',
      purpose: 'audit',
      dataSubjectIds: [],
    });
  },
};
```

If the recorder throws (event store briefly unavailable), the bridge
logs a warning and still returns the response. Losing one access record
is preferable to dropping the response that the auditor is waiting on.

### `renderBundlePdf?: BridgeBundlePdfRenderer` (optional)

The PDF endpoint returns 501 by default. To enable, wire a renderer.
Recommended recipe — bundle through `@tallyseal/verifier`'s
`renderPdf(verifyResult)` against a signed bundle round-trip:

```ts
import { verifyBundle, renderPdf } from '@tallyseal/verifier';
import { signBundleEnvelope } from '@/lib/dsse-signer';

const renderBundlePdf: BridgeBundlePdfRenderer = async (bundle) => {
  const envelope = await signBundleEnvelope(bundle); // your DSSE signer
  const verifyResult = await verifyBundle({ bundleBytes: envelope });
  return renderPdf(verifyResult);
};
```

Or render direct-from-bundle with your own PDF library — the bridge
type signature is `(bundle: AuditBundle) => Promise<Uint8Array>`.

## Bundle PDF

The PDF endpoint is optional because the canonical artifact is the
JSON-LD bundle (byte-deterministic, signable, machine-verifiable). The
PDF is a *report rendered for human review* — auditor-signable per
TKT-VERIFIER-1b.

## Self-hostable

The bridge has zero `@tallyseal/cloud-*` dependencies. Everything runs
in your runtime, against your database, with no Tallyseal-cloud
round-trip. `@tallyseal/verifier` is an **optional peer dep** — only
needed if you wire the PDF endpoint.

## License

MIT.
