# @tallyseal/admin-pr-adapter

> Customer-installed PR authorship. When the Tallyseal admin viewer
> deploys an IntentSpec edit, this adapter authors a PR against your
> own GitHub repo via a per-customer GitHub App. Your CI gates the
> merge — Tallyseal never deploys to your runtime. MIT.

[Sprint E design memo](https://github.com/tallyseal/tallyseal/blob/main/docs/notebook/02-product/sprint-e-visual-editor-design.md)
· [TKT-ADMIN-PR-ADAPTER spec](https://github.com/tallyseal/tallyseal/blob/main/docs/notebook/09-operating/tkt-admin-pr-adapter-spec.md)

---

## What this is

`@tallyseal/admin-pr-adapter` is the **customer-installed** package
that the admin-viewer's "Deploy" button reaches through. It:

1. Accepts a parsed `IntentSpec` from the editor + a free-text
   description of the change.
2. Emits the canonical TypeScript source via
   `@tallyseal/spec-emitter`'s `emit()`.
3. Runs `roundtripTest()` defensively to catch editor-induced
   regressions one layer earlier than the per-emit CI test.
4. Reads the currently-deployed source from your repo via the GitHub
   Contents API.
5. Computes AST-level equivalence — skips the deploy if nothing
   changed structurally.
6. Creates a deploy branch (`tallyseal-deploy/<intentName>-<ts>`),
   updates the spec file, opens a PR against your default branch with
   the canonical [commit message format](#commit-message-format).
7. Records a `BridgeAccessEvent` for every attempt (success or
   failure).

**Tallyseal never deploys to your runtime.** Your CI gates the merge;
your engineer reviews + merges. The deploy app's commit message
records the actor identity (compliance-officer / individual) + the
bridge-access event id (audit trail).

## What this is NOT

- Not a write path to your runtime — only your repo.
- Not a federation gateway — single-tenant install per customer.
- Not a hosted service — runs in your customer runtime.
- Not a replacement for hand-editing TS — engineers can still drop to
  source for advanced changes.

## Install

```bash
pnpm add @tallyseal/admin-pr-adapter @octokit/auth-app @octokit/request
```

`@octokit/auth-app` + `@octokit/request` are peer deps you'll already
have if your runtime uses Octokit; they're listed as explicit
dependencies here so the adapter is self-contained when used standalone.

## GitHub App setup

Per Sprint E 3-gate LOCKED (a): every customer installs their own App
(named `tallyseal-spec-deployer` or your preferred identity). The App
is created once per customer; the installation is per-repo.

**Required permissions** (App-level, granted per install):

| Permission | Scope | Why |
|---|---|---|
| `contents` | `write` | Read current source + create deploy branch + commit changes |
| `pull_requests` | `write` | Open the PR after committing |

**Forbidden permissions**:

- `repo` — way too broad; the adapter should NEVER need this.
- `org:admin` — never required.
- `members` — never required.
- `actions:write` — the adapter does not trigger workflows.

**Per spec §7-b**: GitHub does not currently scope `contents:write` to a
subdirectory — granting `contents:write` gives the App write access to
the entire repo's content surface. This is a GitHub limitation, not a
Tallyseal one. Document this in your customer's onboarding copy.

### Generating the credentials

After creating the App in your GitHub Organization Settings → Developer
Settings → GitHub Apps → New GitHub App:

1. Copy the App ID (numeric, visible on the App settings page).
2. Generate + download a private key (`.pem`).
3. Install the App on your customer's org and copy the
   `installationId` from the install settings URL
   (`.../installations/<installationId>`).

Pass these to `createPrAdapter` (see below). Store the private key in
your secret manager; never commit it to source.

## Quickstart

```ts
import { createPrAdapter } from '@tallyseal/admin-pr-adapter';
import { accessRecorder } from '@/lib/admin-bridge-wiring';

const adapter = createPrAdapter({
  githubApp: {
    appId: Number(process.env.TALLYSEAL_GH_APP_ID),
    privateKey: process.env.TALLYSEAL_GH_APP_PRIVATE_KEY!,
    installationId: Number(process.env.TALLYSEAL_GH_INSTALLATION_ID),
  },
  repo: {
    owner: 'your-org',
    name: 'your-app',
    defaultBranch: 'main',
  },
  specsDirectory: 'apps/admin/lib/intake/specs',
  fileExtension: '.intent.ts',
  audit: accessRecorder,
  packageVersion: '0.0.1', // from your pinned package.json
});
```

The bridge wiring (see `@tallyseal/admin-bridge@0.1.0`'s
`POST /tallyseal-bridge/intent/:name/deploy` endpoint) is what calls
`adapter.deploy(...)`. Customer-side runtime code rarely calls the
adapter directly.

## API

### `createPrAdapter(config: PrAdapterConfig): PrAdapter`

The production factory. Returns a `PrAdapter` with one method:

```ts
adapter.deploy(request: DeployRequest): Promise<DeployOutcome>
```

### `DeployRequest`

```ts
interface DeployRequest {
  intentName: string;            // e.g., "EnrollmentIntake"
  proposedSpec: ParsedCrawcusSpec;
  actor: BridgeActor;            // resolved by bridge OIDC hook
  humanDescription: string;
}
```

### `DeployOutcome = DeployResult | DeployFailure`

```ts
type DeployResult = {
  kind: 'ok';
  prUrl: string;
  prNumber: number;
  commitSha: string;
  bridgeAccessEventId: string;
};

type DeployFailure =
  | { kind: 'auth-failure'; detail: string }
  | { kind: 'app-not-installed'; detail: string }
  | { kind: 'permissions-insufficient'; detail: string }
  | { kind: 'source-not-modifiable'; detail: string }
  | { kind: 'round-trip-failure'; detail: string }
  | { kind: 'github-api-error'; detail: string };
```

`detail` strings are human-readable but MUST NOT be echoed verbatim
to end-users — they may leak file paths or repo identities.

## Commit message format

Locked per spec §3:

```
spec(<intentName>): <human description of change>

Spec authored via Tallyseal admin editor by <actor-name> (<actor-role>).
PR audit-record: <bridge-access-event-id>
Tallyseal-deploy-app: tallyseal-spec-deployer

Generated by @tallyseal/admin-pr-adapter@<version>
```

Subject is conventional-commit. Body has three meta-lines (actor +
audit + app identity) and a trailer line (generated-by). Customer's
CI consumes the metadata via the commit-message body.

## Surface-don't-silently-choose

Per spec §7, the adapter surfaces (rather than silently choosing) for:

- **(a)** `@octokit/auth-app` semver in the workspace differs from the
  adapter's required version → pin or upgrade; surface to founder.
- **(b)** GitHub limits `contents:write` to whole-repo scope (no
  subdirectory restriction) → documented above; surface in customer
  install copy.
- **(c)** Customer spec directory contains non-spec files (e.g.,
  shared helper TS) → tighten filter; surface to customer.
- **(d)** OIDC actor token missing role / id / name claims → adapter
  fails with `auth-failure` before authoring an unattributable
  commit.
- **(e)** Round-trip byte-equivalence fails on the customer's spec →
  adapter fails with `round-trip-failure`; engineer must hand-edit
  source.

## Testing

```bash
pnpm --filter @tallyseal/admin-pr-adapter test
```

Test fixtures include:
- Happy path (PR opens with locked commit-message body)
- 6 failure paths (auth-failure / app-not-installed /
  permissions-insufficient / source-not-modifiable /
  round-trip-failure / github-api-error)
- Mocked GitHub client per-method
- No-change deploy returns `source-not-modifiable`

## License

MIT. Per [`c3-open-core-boundary.md`](https://github.com/tallyseal/tallyseal/blob/main/docs/notebook/01-strategy/c3-open-core-boundary.md):
the customer-facing PR authorship path is OSS forever (Option D —
Wide-OSS / Operated-content premium). Paid services
(`@tallyseal/cloud-*`) sit above the npm layer, never on a scope
boundary.
