# @tallyseal/extractor

Layer-3 AI extractor primitive + synthetic eval-corpus runner for
Tallyseal. Implements the `Projector` interface from `@tallyseal/core`.

> ⚠️ **What this package is NOT** (per HF feedback 2026-06-02 item 2 — disambiguating a real planning confusion):
>
> - **NOT a PII detector** — PII tokenisation lives in [`@tallyseal/core/pii`](../core/src/pii/).
> - **NOT an Article 9 special-category detector** — special-category prohibition is the [`specialCategoryProhibition` Contract](../regulations-gdpr/src/contracts/special-category-prohibition.ts) in `@tallyseal/regulations-gdpr`.
> - **NOT an entity / intent extractor for production runtime** — that is the `Projector` interface itself in `@tallyseal/core`, implemented per-customer (or by future `@tallyseal/extractor-anthropic` / `-openai` adapter packages).
>
> **What this package IS**: a Projector eval-corpus runner — test infrastructure for measuring projector accuracy against versioned synthetic cases (`defineEvalCorpus`, `runEvalCorpus`, `checkRegression`). Spiritually it is the projector's TCK. The package name will likely rename to `@tallyseal/eval-corpus` or `@tallyseal/projector-tck` at the CRAWCUS spec spin-out (Y1 H2) to remove the ambiguity that prompted this clarification.

Per **Q7 LOCKED 2026-05-21**: synthetic-only eval cases at v0.0.1.
Consent-gated transcript contribution lands at v1.0+.

## Install

```bash
pnpm add @tallyseal/extractor @tallyseal/core
```

## Use — define synthetic eval cases

```ts
import { defineCrawcusSpec, field } from '@tallyseal/core';
import { defineEvalCorpus } from '@tallyseal/extractor';

const spec = defineCrawcusSpec({
  key: 'CreateCourse',
  projection: 'Course',
  version: 1,
  fields: {
    title: field.string().required(),
    subject: field.enum(['math', 'science', 'english', 'history']).required(),
  },
  readiness: ({ has }) => has('title', 'subject'),
});

export const courseEvalCorpus = defineEvalCorpus(spec, [
  {
    id: 'happy-path-math',
    description: 'Title + subject extract cleanly from a clear utterance',
    intentKey: 'CreateCourse',
    specVersion: 1,
    input: { message: 'Make a course called Intro to Algebra in math' },
    expectations: [
      { fieldKey: 'title', value: 'Intro to Algebra', minConfidence: 0.85 },
      { fieldKey: 'subject', value: 'math', minConfidence: 0.85 },
    ],
  },
  // ... 20-30 more cases per CrawcusSpec — covering happy paths,
  // ambiguous inputs, edge cases per ratchet #7
]);
```

## Run an eval

```ts
import { runEvalCorpus, checkRegression } from '@tallyseal/extractor';

const report = await runEvalCorpus({
  corpus: courseEvalCorpus,
  spec,
  projector: yourProjector, // implements @tallyseal/core's Projector
  tenant,
  ai: anthropicAdapter,
  pii: presidioAdapter,
});

console.log(`Pass-rate: ${(report.passRate * 100).toFixed(1)}%`);

// Ratchet #7 regression gate
const baseline = await loadBaselineReportFromLastRelease();
const regression = checkRegression(report, baseline);
if (!regression.ok) {
  throw new Error(regression.reason);
}
```

## What ships at v0.0.1

- **EvalCase + EvalCorpus types** — versioned per CrawcusSpec
- **EvalExpectation matching** — value + minimum confidence per field
- **Runner** — orchestrates a `Projector` over a corpus; produces
  `CorpusReport` with per-case + per-expectation diagnostics
- **Regression gate** (`checkRegression`) — fails build if pass-rate
  drops more than `tolerancePercentagePoints` (default 0.5pp) per
  ratchet #7 + NFR C4
- **Bounded concurrency** — `concurrency: N` option for parallel
  case evaluation when the Projector is rate-limit-aware

## What defers to v1.0

- `@tallyseal/eval-corpus-public` — community-contributed
  anonymised transcripts under consent gate
- Per-tenant private corpora (residency-bound)
- Auditor-attested per-vertical corpora (Cloud operated-content per C3)
- Cross-tenant differential-privacy aggregation
- Specific Projector implementations (currently Projector is interface-only
  in core; concrete extractors per AI provider land separately)

## Status

v0.0.1 — pure orchestration + scoring. The Projector itself is the
customer's responsibility (or a future `@tallyseal/extractor-anthropic` /
`-openai` / etc. adapter — those packages don't exist yet).

12 tests pass:
- 6 runner cases (happy + mixed + missing + low-confidence + throwing
  + invariant checks)
- 1 corpus-empty case
- 5 regression-gate cases (held / within-tolerance / dropped /
  custom-tolerance / intent-mismatch)

## License

MIT.
