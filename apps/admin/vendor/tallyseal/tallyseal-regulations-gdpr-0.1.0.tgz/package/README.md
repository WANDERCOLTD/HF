# @tallyseal/regulations-gdpr

GDPR Contract factories + FieldCompliance defaults for Tallyseal.

Pinned version: **`gdpr@2025-Q1`**.

## Install

```bash
pnpm add @tallyseal/regulations-gdpr
```

## Use

```ts
import { defineCrawcusSpec, defineCompliance } from '@tallyseal/core';
import {
  minorConsent,
  gdprPersonalDataDefaults,
  GDPR_VERSION,
} from '@tallyseal/regulations-gdpr';

// In your tallyseal.compliance.ts:
export default defineCompliance({
  regulations: [GDPR_VERSION],
  fields: {
    ...gdprPersonalDataDefaults('Course'),
    'Course.learnerAge': { pii: 'personal' },
    'Course.parentalConsentEventId': { pii: 'personal' },
  },
  // ... rest of the manifest
});

// In your CrawcusSpec:
defineCrawcusSpec({
  key: 'CreateCourse',
  // ...
  contracts: {
    invariants: [
      minorConsent({
        ageField: 'learnerAge',
        consentField: 'parentalConsentEventId',
        minorAge: 16,
      }),
    ],
  },
});
```

## What ships in 0.0.1 (commit 4d minimum)

- `minorConsent({ ageField, consentField, minorAge? })` — Art. 8(1)
- `gdprPersonalDataDefaults(projection)` — common personal-data fields
- `gdprSpecialCategoryDefaults(projection)` — Art. 9 special categories
- `GDPR_VERSION` — `'gdpr@2025-Q1'`

## Roadmap

- Art. 6 lawful-basis factories (per-purpose-keyed)
- Art. 9 explicit-consent gate (currently enforced at writeEvent level)
- Art. 15 DSAR helpers (request shape + response builders)
- Art. 17 erasure helpers
- Art. 22 automated-decision-explanation
- Art. 35 DPIA template
- Quarterly version refreshes (`gdpr@2025-Q2`, `gdpr@2025-Q3`, …)

## License

MIT.
