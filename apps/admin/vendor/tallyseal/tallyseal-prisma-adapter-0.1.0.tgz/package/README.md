# @tallyseal/prisma-adapter

Prisma-backed `EventStorePort` + default `ProjectionPort` + SQL
migrations for Tallyseal.

Per **Q6 LOCKED 2026-05-21 — Option A**: ships immutable SQL
migrations in `migrations/`, applied by a hand-rolled runner
(`applyMigrations(client)`); the customer's `schema.prisma` does NOT
need any Tallyseal model declarations — the adapter uses raw SQL
(`$queryRawUnsafe` / `$executeRawUnsafe`) against the tables our
migrations create.

## Install

```bash
pnpm add @tallyseal/prisma-adapter @tallyseal/core @prisma/client
```

## Setup — one-time

```ts
import { PrismaClient } from '@prisma/client';
import { applyMigrations } from '@tallyseal/prisma-adapter';

const prisma = new PrismaClient();
const result = await applyMigrations(prisma);
console.log(`Applied: ${result.applied.length}, skipped: ${result.skipped.length}`);
```

Or via the (future) CLI:

```bash
npx @tallyseal/generator migrate
```

Idempotent — safe to run on every deploy.

## Wire into `defineConfig`

```ts
import { defineConfig } from '@tallyseal/core';
import { PrismaEventStore, PrismaNoopProjection } from '@tallyseal/prisma-adapter';

const prisma = new PrismaClient();

export default defineConfig({
  eventStore: new PrismaEventStore(prisma),
  projection: new PrismaNoopProjection(),
  // ... other ports
});
```

## Same-transaction guarantee (ratchet #13)

`PrismaEventStore.begin(tenant, fn)` opens a `client.$transaction(...)`.
Inside the callback, `tx.__tx.raw` is the Prisma transaction client
— customer's per-intent reducers (registered via
`defineProjection({...})`) get this through `ReducerCtx.tx`. The
event append + the projection write commit atomically.

## Row mappers

Pure row → runtime mappers for read paths (`apps/admin-bridge` callbacks, customer queries):

| Helper | Maps | From |
|---|---|---|
| `rowToEvent(row)` | `Event` | `TallysealEventRow` (canonical `tallyseal_event` row) |
| `rowToIntent(row)` | `Intent` | `TallysealIntentRow` (canonical `tallyseal_intent` row) |

Use the brand-cast typed-id shape — the helpers return values structurally assignable to `IntentId` / `TenantId` / `IntentKey` without further casting.

## Tables created

| Table | Purpose |
|---|---|
| `tallyseal_event` | Append-only event log; UUIDv7 IDs; UNIQUE(intent_id, version); GIN index on data_subject_ids for DSAR |
| `tallyseal_intent` | Intent runtime state + accumulated snapshot |
| `tallyseal_suggestion` | Suggestion lifecycle records (Art. 14 surface) |
| `_tallyseal_migrations` | Internal: applied-migration ledger with SHA-256 checksums |

All tables are prefixed `tallyseal_` to avoid collisions; all carry
`tenant_id` + index. Partitioning is an adapter optimisation
deferred to S1 load testing.

## Migrations are immutable (ratchet #4)

Migrations in `migrations/` are forward-only. The runner records a
SHA-256 checksum of each file when applied. If a previously-applied
file is later edited, the runner REFUSES on next run with a clear
error — never silently re-applies.

To change schema after release: add a NEW forward migration with a
higher numeric prefix. Never edit historical files.

## Status

v0.0.1 — type-conformance tested via in-memory mock. Real-database
integration tests (against `pg-mem` or `@testcontainers/postgresql`)
land in a follow-up; the mock verifies the adapter constructs the
right SQL + propagates the transaction correctly. The bundled SQL
itself is tested via the migration runner's checksum invariants.

## License

MIT.
